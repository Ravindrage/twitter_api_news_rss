<?php

//ini_set('display_errors',1);
//ini_set('log_errors',1);
//var_dump(ini_get('allow_url_fopen'));
include("connection.php");
global $conn;

$sql = "SELECT * FROM category ";
$result = $conn->query($sql);
	
$result->num_rows; 

if ($result->num_rows > 0) {							
$incre_num = 1;

foreach($result as $row) {   
               
$rss = simplexml_load_file($row['url']);
$i=0;
    
foreach($rss->channel->item as $item) {
    
     $title = (string)$item->title[0];  echo '</br>';
     $description = (string)$item->description[0];  echo '</br>';
     $link = $item->link;  echo '</br>';
     $guid = $item->guid;  echo '</br>';
     $pubDate = $item->pubDate; echo '</br>';
    //echo $media  = $item->media;   echo '</br>';
    
    $thumbAttr = $item->children('media', true)->thumbnail->attributes();
    // or preferably the namespace name, read note below for an explanation
    $thumbAttr = $item->children('http://search.yahoo.com/mrss/')->thumbnail->attributes();
    
     $media = $thumbAttr['url']; echo '</br>';
    //echo '</br>';
    echo $i++; 
     $imagename = basename($media); //echo "  ";
    
     $_SERVER['DOCUMENT_ROOT'];

    echo $row['category']; echo '</br>';

    copy($media,'images/'.$row['category'].'/'.$imagename);
    
    echo $_SERVER['DOCUMENT_ROOT'].'/images/'.$row['category'].'/'.$imagename ;  //echo '<br>';
    $content = file_get_contents($media);
    $fp = fopen($_SERVER['DOCUMENT_ROOT'].'/images/'.$row['category'].'/'.$imagename, "w+");
    fwrite($fp, $content);
    fclose($fp);
    
    $category_id = $row['id'] ; 
    $descriptionn = str_replace('"', '', $description); 
    $titlen = str_replace('"', '', $title); 

    $sql123 = 'SELECT * FROM world_rss  where category_id = "'.$category_id.'" and title = "'.$titlen.'" ';
    $result123 = $conn->query($sql123);	
          
if ($result123->num_rows > 0) {	
    }else
    {
  
     $sql = 'Insert into world_rss(title,description,link,guid,pubDate,media,category_id,datetime) values   ("'.$titlen.'","'.$descriptionn.'","'.$link.'","'.$guid.'","'.$pubDate.'","'.$imagename.'","'.$category_id.'",now())';  
 
     $result = $conn->query($sql) ;

    }
             
   }
    
}
    
}



?>
