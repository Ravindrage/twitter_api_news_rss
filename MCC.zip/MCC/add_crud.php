<html>
<head>
	<title>Add Data</title>
</head>

<body>
<?php
//including the database connection file
include("../connection.php");

session_start();

if(isset($_SESSION['ID_your_site'])){ 

if(isset($_POST['Submit'])) {
	$tweet_url = $_POST['tweet_url'];
	// $age = $_POST['age'];
	$tweet_text = $_POST['tweet_text'];

	// checking empty fields
	//if(empty($name) || empty($age) || empty($email)) {
          if(empty($tweet_url) || empty($tweet_text)) {

		if(empty($tweet_url)) {
			echo "<font color='red'>Tweet_url field is empty.</font><br/>";
		}

		//if(empty($age)) {
			//echo "<font color='red'>Age field is empty.</font><br/>";
		//}

		if(empty($tweet_text)) {
			echo "<font color='red'>Tweet_text field is empty.</font><br/>";
		}

		//link to the previous page
		echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
	} else {
		// if all the fields are filled (not empty)

		//insert data to database
		//$result = mysqli_query($conect, "INSERT INTO twitter_url(name,age,email) VALUES('$name','$age','$email')");
                $sql = "INSERT INTO twitter_url(tweet_url,tweet_text) VALUES('$tweet_url','$tweet_text')";
                $result = mysqli_query($conect,$sql);

		//display success message
		echo "<font color='green'>Data added successfully.";
		echo "<br/><a href='members.php'>View Result</a>";
	}
}
} else 
{
 //if the Session does not exist, they are taken to the login screen
	header("Location: index.php");
}
?>
</body>
</html>
