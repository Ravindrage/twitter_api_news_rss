<?php

define ("db-host", "localhost");
define ("user-name", "root");
define ("password", "f8B577jx");
define ("database", "hpf");

$link=mysql_connect("localhost","root","f8B577jx") or die ("errror");

$db=mysql_select_db("hpf", $link)or die ("errror");

$conect = mysqli_connect("localhost","root","f8B577jx","hpf") or die(mysql_error());

?>
