<?php
// including the database connection file
include("../connection.php");
session_start();

//echo 'adfdsf';
//exit;

if(isset($_SESSION['ID_your_site'])){ 

if(isset($_POST['update']))
{      // echo 'hello' ; exit;
	$id = $_POST['id'];
	$tweet_url=$_POST['tweet_url'];
	//$age=$_POST['age'];
	$tweet_text=$_POST['tweet_text'];

	// checking empty fields
	//if(empty($name) || empty($age) || empty($email)) {
          if(empty($tweet_url) || empty($tweet_text)) {

		if(empty($tweet_url)) {
			echo "<font color='red'>Name field is empty.</font><br/>";
		}

		/*if(empty($age)) {
			echo "<font color='red'>Age field is empty.</font><br/>";
		}*/

		if(empty($tweet_text)) {
			echo "<font color='red'>Email field is empty.</font><br/>";
		}
	} else {
		//updating the table
		// $result = mysqli_query($conect, "UPDATE twitter_url SET tweet_url='$name',age='$age',email='$email' WHERE id=$id");
                $result = mysqli_query($conect, "UPDATE twitter_url SET tweet_url='$tweet_url', tweet_text='$tweet_text' WHERE id=$id");

		//redirectig to the display page. In our case, it is index.php
		header("Location: members.php");
	}
}
?>
<?php
//getting id from url
$id = $_GET['id'];

//selecting data associated with this particular id
$result = mysqli_query($conect, "SELECT * FROM twitter_url WHERE id=$id");

while($res = mysqli_fetch_array($result))
{
	$tweet_url = $res['tweet_url'];
	// $age = $res['age'];
	$tweet_text = $res['tweet_text'];
}
?>
<html>
<head>
	<title>Edit Data</title>
</head>

<body>
	<p style="text-align:-moz-center;"><a href="members.php">Home</a></p>
	<br/><br/>
         <div style="text-align:-moz-center">
	<form name="form1" method="post" action="edit.php">
		<table border="0">
			<tr>
				<td>Twitter URL</td>
				<td><input type="text" name="tweet_url" value=<?php echo $tweet_url; ?>></td>
			</tr>
			<!--<tr>
				<td>Category_</td>
				<td><input type="text" name="age" value=<?php echo $age;?>></td>
			</tr-->
			<tr>
				<td>Text After Tweet</td>
				<td><input type="text" name="tweet_text" value=<?php echo $tweet_text; ?>></td>
			</tr>
			<tr>
				<td><input type="hidden" name="id" value=<?php echo $_GET['id'];?>></td>
				<td><input type="submit" name="update" value="Update"></td>
			</tr>
		</table>
	</form>
</div>
</body>
</html>
<?php } else {
        //if the Session does not exist, they are taken to the login screen
	header("Location: index.php");
 }
 
?>
