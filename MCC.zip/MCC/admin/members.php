<?php
//Connects to your Database

include("../connection.php");
session_start();

ini_set('display_errors', 1); 

 //checks cookies to make sure they are logged in
//print_r($_SESSION['ID_your_site']);

 if(isset($_SESSION['ID_your_site'])){

       
  $username = $_SESSION['ID_your_site'];
  $pass =     $_SESSION['Key_your_site'];
  //$check = mysql_query("SELECT * FROM users WHERE username = '$username'")or die(mysql_error());
  $check = mysqli_query($conect,"SELECT * FROM users WHERE username = '$username'");
//echo 'hello';
 // while($info = mysql_fetch_array($check)){
    while($info = mysqli_fetch_array($check)) {
          // echo 'hello';    

		//if the cookie has the wrong password, they are taken to the login page
 		if ($pass != $info['password']){
			header("Location: index.php");
 		}
		//otherwise they are shown the admin area
		else{
 			 echo '<p style="text-align:center;"><a href="members.php">Admin Area</a></p>';
 	 echo "<div style='text-align:center;align:center;'>";                
          echo "<a href='news_status.php'>News Status</a>";
 ?>
                          
                         <a href="logout.php" class="logout" style='text-align:center'>Logout</a> <a href="add_crud.html">Add New Data</a></div> <?php
               
     $result = mysqli_query($conect,"SELECT * FROM twitter_url ORDER BY id DESC"); // using mysqli_query instead
?>

<html>
<head>
	<title>Homepage</title>
</head>

<body>
<div style="text-align:-moz-center">
<!--<a href="add_crud.html">Add New Data</a>--><br/><br/>

	<table width='80%' border=0 style="border:1px solid #000">

	<tr bgcolor='#CCCCCC'>
		<td>Twitter URL</td>
		<!-- <td>Age</td> -->
		<td>Text After Tweet</td>
		<td>Update</td>
	</tr>
	<?php
	//while($res = mysql_fetch_array($result)) { // mysql_fetch_array is deprecated, we need to use mysqli_fetch_array
	while($res = mysqli_fetch_array($result)) {
               // print_r($res);
		echo "<tr>";
		echo "<td>".$res['tweet_url']."</td>";
		// echo "<td>".$res['age']."</td>";
		echo "<td>".$res['tweet_text']."</td>";
		echo "<td><a href=\"edit.php?id=$res[id]\">Edit</a> | <a href=\"delete.php?id=$res[id]\" onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a></td>";
	}
	?>
	</table>
</div>
</body>
</html>

   <?php
 	}
	}
}

 else{ //if the Session does not exist, they are taken to the login screen
	header("Location: index.php");
 }
 ?>
