

<?php
//Connects to your Database

include("../connection.php");
session_start();

 //checks cookies to make sure they are logged in
//print_r($_SESSION['ID_your_site']);

 if(isset($_SESSION['ID_your_site'])){

         
	if(isset($_REQUEST['submit']) and !empty($_REQUEST['submit']))
	{ 
  //  print_r($_REQUEST);
    $category_id = $_REQUEST['category_id'];
    $news_id = implode(',',$_REQUEST['news_status']); 
    
   // $sql = "update world_rss set status=0 where category_id = $category_id";
     $check = mysqli_query($conect,"update world_rss set status=0 where category_id = $category_id");
   // mysql_query($sql)or die(mysql_error()); 
   
   // $sql = "update world_rss set status=1 where id in ($news_id) and category_id = $category_id";
   // mysql_query($sql)or die(mysql_error()); 
    $check = mysqli_query($conect,"update world_rss set status=1 where id in ($news_id) and category_id = $category_id");
    	}

       $username = $_SESSION['ID_your_site'];
       $pass =     $_SESSION['Key_your_site'];
       //$check = mysql_query("SELECT * FROM users WHERE username = '$username'")or die(mysql_error());
       $check = mysqli_query($conect,"SELECT * FROM users WHERE username = '$username'");

 	//while($info = mysql_fetch_array($check)){
        while($info = mysqli_fetch_array($check)) {
               
 //echo "hello";
       // exit;


		//if the cookie has the wrong password, they are taken to the login page
 		if ($pass != $info['password']){
			header("Location: index.php");
 		}
		//otherwise they are shown the admin area
		else{ echo '<p style="text-align:center;"><a href="members.php">Admin Area</a></p>';
 	 echo "<div style='text-align:center;align:center;'>";                
          echo "<a href='news_status.php'>News Status</a>";
 ?>
                          
                         <a href="logout.php" class="logout" style='text-align:center'>Logout</a> <a href="add_crud.html">Add New Data</a></div><?php
                    
            if(isset($_REQUEST['catid']) and !empty($_REQUEST['catid']))
             {  $catid = $_REQUEST['catid']; } else { $catid = 1;  }

               
     $result = mysqli_query($conect,"SELECT * FROM world_rss where category_id = $catid ORDER BY id DESC"); // using mysqli_query instead
?>

<html>
<head>
	<title>Homepage</title>
</head>

<body>
<div style="text-align:-moz-center">
<br/><br/>
        <form action="news_status.php" method="POST" name="news_status" id="news_status">
         <input type="hidden" name="category_id" id="category_id" value="<?php echo $catid; ?>">
        <table style="background-color:#EFEFEF; width:80%"><tr>
        <?php 
          //$menucat = mysql_query("SELECT * FROM category ")or die(mysql_error());
            $menucat = mysqli_query($conect,"SELECT * FROM category");

  	  //while($menucatinfo = mysql_fetch_array($menucat)){
            while($menucatinfo = mysqli_fetch_array($menucat)) {
           ?> <td style="padding:5px;"> <a href="news_status.php?catid=<?php echo $menucatinfo['id']; ?>"> 
              <?php echo ucfirst($menucatinfo['cat_name']); ?> </a></td>
           <?php }
         ?>
        </tr>   
        </table>
	<table width='80%' border=0 style="border:1px solid #000">
	<tr bgcolor='#CCCCCC'>
                <td>ID</td>
		<td style="text-align:center;">Status</td>
		<!-- <td>Age</td> -->
		<td>News Title</td>
		<td>Update</td>
	</tr>
	<?php $i=0;
	//while($res = mysql_fetch_array($result)) { // mysql_fetch_array is deprecated, we need to use mysqli_fetch_array
	while($res = mysqli_fetch_array($result)) {
               // print_r($res);
                   $i++ ; 
		echo "<tr>"; ?>
                <td style="text-align:center;"><?php echo $i; ?></td>
		<td style="text-align:center;" ><input type="checkbox" name="news_status[]" value="<?php echo $res['id'];  ?>" <?php if( $res['status']=='1'){ echo 'checked';} ?> ></td>
             <?php
		// echo "<td>".$res['age']."</td>";
		//echo "<td>".$res['tweet_text']."</td>";
		echo "<td>".$res['title']."</td>";
	}
          
	?><tr><td>&nbsp;	</td></tr>
         <tr><td colspan="3" style="text-align:center;"> <input type = "submit" name ="submit" value="Submit" id="submit"></td></tr>
	</table></form>
</div>
</body>
</html>

   <?php
 	}
	}
}

 else{ //if the Session does not exist, they are taken to the login screen
	header("Location: index.php");
 }
 






?>
