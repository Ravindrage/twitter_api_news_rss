<?php 

include("connection.php");
global $conn;

?>

<!DOCTYPE html>

<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Tesco.press</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- for fontawesome icon css file -->
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <!-- for content animate css file -->
    <link rel="stylesheet" href="css/animate.css">
    <!-- google fonts  -->
    <link href='http://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Varela' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>   
    <!-- for news ticker css file -->
     <link href="css/li-scroller.css" rel="stylesheet">
     <!-- slick slider css file -->
    <link href="css/slick.css" rel="stylesheet">
    <!-- for fancybox slider -->
     <link href="css/jquery.fancybox.css" rel="stylesheet">    
    <!-- website theme file -->
    <!-- <link href="css/theme-red.css" rel="stylesheet"> -->
 
     <link href="css/theme.css" rel="stylesheet">
    <!-- main site css file -->    
    <link href="style.css" rel="stylesheet">
 

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

   <style>

<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- leader -->
<ins class="adsbygoogle"
     style="display:inline-block;width:728px;height:90px"
     data-ad-client="ca-pub-9563089652950762"
     data-ad-slot="1823822426"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>


  </style>



  </head>
<body>
  <!-- =========================
    //////////////This Theme Design and Developed //////////////////////
    //////////// by www.wpfreeware.com======================-->

  <!-- Preloader -->
  <div id="preloader">
    <div id="status">&nbsp;</div>
  </div>
  <!-- End Preloader -->
   
  <a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a>
  
  <div class="container">
    <!-- start header section -->
    <!-- End header section --> 
    <!-- start nav section --> 
    <?php include("menu.php");   ?>
    
    <!-- start slider section -->
    <section id="sliderSection">
      <div class="row">
        <div class="col-lg-8 col-md-8 col-sm-8">
            <!-- Set up your HTML -->
          <div class="slick_slider">


            
           <?php  
             for($i=0;$i<7;$i++){

            $sqllatest = "SELECT *,id as wid from world_rss where category_id=$i  ORDER BY UNIX_TIMESTAMP(datetime) DESC limit 0,1";

            //$sqllatest = "SELECT *,wrs.id as wid FROM world_rss as wrs left join category as catg  on wrs.category_id=catg.id  group by category_id  ORDER BY UNIX_TIMESTAMP(datetime) DESC limit 0,5";
                               
            $resultlatest = $conn->query($sqllatest);	
            $resultlatest->num_rows; 

            if ($resultlatest->num_rows > 0) {							
            $incre_num = 1;

            foreach($resultlatest as $rowlatest) {  ?>
            
            <div class="single_iteam">
              <a href="single_page.php?newsid=<?php echo $rowlatest['wid']; ?>">  <img src="/images/<?php echo $rowlatest['category'].'/'.$rowlatest['media'];    ?>"></a>
              <div class="slider_article">
                <h2><a class="slider_tittle" href="single.php?newsid=<?php echo $rowlatest['wid']; ?>"><?php echo $rowlatest['title'];    ?></a></h2>
                <p><?php echo $rowlatest['description'];    ?></p>
              </div>
            </div>
            
                      
            <?php  } } }  ?>
         
           
           
          </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-4">
          <div class="latest_post">
            <h2><span>Latest post</span></h2>
            <div class="latest_post_container">
              <div id="prev-button"><i class="fa fa-chevron-up"></i></div>
              <ul class="latest_postnav">
                  
            <?php  
              for($i=0;$i<7;$i++){

            $sqllatest = "SELECT *,id as wid from world_rss where category_id=$i  ORDER BY UNIX_TIMESTAMP(datetime) DESC limit 0,1";

             //$sqllatest = "SELECT *,wrs.id as wid FROM world_rss as wrs left join category as catg  on wrs.category_id=catg.id  group by category_id  ORDER BY UNIX_TIMESTAMP(datetime) DESC limit 0,5";
                               
            $resultlatest = $conn->query($sqllatest);	
            $resultlatest->num_rows; 

            if ($resultlatest->num_rows > 0) {							
            $incre_num = 1;

            foreach($resultlatest as $rowlatest) {  ?>
            
            <li>
                  <div class="media">
                    <a href="single_page.php?newsid=<?php echo $rowlatest['wid']; ?>" class="media-left">
                      <img src="/images/<?php echo $rowlatest['category'].'/'.$rowlatest['media'];    ?>">
                    </a>
                    <div class="media-body">
                      <a href="single_page.php?newsid=<?php echo $rowlatest['wid']; ?>" class="catg_title"> <?php echo $rowlatest['title'];    ?> </a>                        
                    </div>
                  </div>
            </li>    
                      
            <?php  } } }  ?>
                
              </ul>
             <div id="next-button"><i class="fa  fa-chevron-down"></i></div>
            </div>
          </div>
        </d iv>
      </div>
    </section><!-- End slider section -->
     <!-- =========================
      //////////////This Theme Design and Developed //////////////////////
      //////////// by www.wpfreeware.com======================-->

    <!-- ==================start content body section=============== -->
    <section id="contentSection">
      <div class="row">
        <div class="col-lg-8 col-md-8 col-sm-8">
          <div class="left_content">
            <div class="single_post_content">
              <h2><span>Business</span></h2>
                
                <div class="single_post_content_left">
                <ul class="business_catgnav  wow fadeInDown">
                  
                 <?php $sqllatest = "SELECT *,wrs.id as wid FROM world_rss as wrs left join category as catg  on wrs.category_id=catg.id where catg.category='business' ORDER BY UNIX_TIMESTAMP(datetime)DESC limit 1,1 ";
                               
            $resultlatest = $conn->query($sqllatest);	
            $resultlatest->num_rows; 

            if ($resultlatest->num_rows > 0) {							
            $incre_num = 1;

            foreach($resultlatest as $rowlatest) {  ?>
                    
                           
                  <li>
                    <figure class="bsbig_fig">
                      <a href="single_page.php?newsid=<?php echo $rowlatest['wid']; ?>" class="featured_img">
                          <img src="/images/<?php echo $rowlatest['category'].'/'.$rowlatest['media'];    ?> " alt="" style="border:1px;">
                          <span class="overlay"></span>
                      </a>
                      <figcaption>
                        <a href="single_page.php?newsid=<?php echo $rowlatest['wid']; ?>"><?php echo $rowlatest['title']; ?></a>
                      </figcaption>
                        <p><?php echo $rowlatest['description']; ?></p>
                    </figure>
                  </li>
                        
        
            <?php  } }   ?>
                </ul>
              </div>
              <div class="single_post_content_right">
                <ul class="spost_nav">
                    
            <?php $sqllatest = "SELECT *,wrs.id as wid FROM world_rss as wrs left join category as catg  on wrs.category_id=catg.id where catg.category='business' ORDER BY UNIX_TIMESTAMP(datetime) DESC limit 0,5 ";
                               
            $resultlatest = $conn->query($sqllatest);	
            $resultlatest->num_rows; 

            if ($resultlatest->num_rows > 0) {							
            $incre_num = 1;

            foreach($resultlatest as $rowlatest) {  ?>
                    
               <li>
                    <div class="media wow fadeInDown">
                      <a href="single_page.php?newsid=<?php echo $rowlatest['wid']; ?>" class="media-left">
                        <img src="/images/<?php echo $rowlatest['category'].'/'.$rowlatest['media'];    ?> " alt="" style="border:1px;">
                      </a>
                      <div class="media-body">
                      <a href="single_page.php?newsid=<?php echo $rowlatest['wid']; ?>" class="catg_title"> <?php echo $rowlatest['title']; ?></a>                        
                      </div>
                    </div>
                  </li>
                        
        
            <?php  } }   ?>
                    
       
                </ul>
              </div>
            </div>
            <!-- start 2 style category design -->
            <div class="fashion_technology_area">
              <div class="fashion">
                <div class="single_post_content">
                  <h2><span>Education & Family</span></h2>              
                  <ul class="business_catgnav wow fadeInDown">
                   
                     <?php $sqllatest = "SELECT *,wrs.id as wid FROM world_rss as wrs left join category as catg  on wrs.category_id=catg.id  where catg.category='education' ORDER BY UNIX_TIMESTAMP(datetime) DESC limit 1,1";
                               
            $resultlatest = $conn->query($sqllatest);	
            $resultlatest->num_rows; 

            if ($resultlatest->num_rows > 0) {							
            $incre_num = 1;

            foreach($resultlatest as $rowlatest) {  ?>
                    
              
               <li>
                      <figure class="bsbig_fig">
                        <a href="single_page.php?newsid=<?php echo $rowlatest['wid']; ?>" class="featured_img">
                            <img src="/images/<?php echo $rowlatest['category'].'/'.$rowlatest['media'];    ?> " alt="" style="border:1px;">
                            <span class="overlay"></span>
                        </a>
                        <figcaption>
                          <a href="single_page.php?newsid=<?php echo $rowlatest['wid']; ?>"><?php echo $rowlatest['title'];    ?></a>
                        </figcaption>
                          <p><?php echo $rowlatest['description'];    ?></p>
                      </figure>
                    </li>

                        
        
            <?php  } }   ?>
            
                               
                  </ul>
                  <ul class="spost_nav">
                      
             <?php $sqllatest = "SELECT *,wrs.id as wid FROM world_rss as wrs left join category as catg  on wrs.category_id=catg.id  where catg.category='education' ORDER BY UNIX_TIMESTAMP(datetime) DESC limit 0,5";
                               
            $resultlatest = $conn->query($sqllatest);	
            $resultlatest->num_rows; 

            if ($resultlatest->num_rows > 0) {							
            $incre_num = 1;

            foreach($resultlatest as $rowlatest) {  ?>
                    
               <li>
                    <div class="media wow fadeInDown">
                      <a href="single_page.php?newsid=<?php echo $rowlatest['wid']; ?>" class="media-left">
                        <img src="/images/<?php echo $rowlatest['category'].'/'.$rowlatest['media'];    ?> " alt="" style="border:1px;">
                      </a>
                      <div class="media-body">
                        <a href="single_page.php?newsid=<?php echo $rowlatest['wid']; ?>" class="catg_title"> <?php echo $rowlatest['title'];    ?></a>                        
                      </div>
                    </div>
                  </li>
                        
        
            <?php  } }   ?>
            
                  
                </ul>
                </div>
              </div>
              <div class="technology">
                <div class="single_post_content">
                  <h2><span>Politics</span></h2>

              
                  <ul class="business_catgnav">
                   
                    <?php $sqllatest = "SELECT *,wrs.id as wid FROM world_rss as wrs left join category as catg  on wrs.category_id=catg.id where catg.category='politics' ORDER BY UNIX_TIMESTAMP(datetime) DESC limit 1,1 ";
                               
            $resultlatest = $conn->query($sqllatest);	
            $resultlatest->num_rows; 

            if ($resultlatest->num_rows > 0) {							
            $incre_num = 1;

            foreach($resultlatest as $rowlatest) {  ?>
                    
                  
                     <li>
                      <figure class="bsbig_fig wow fadeInDown">
                        <a href="single_page.php?newsid=<?php echo $rowlatest['wid']; ?>" class="featured_img">
                            <img src="/images/<?php echo $rowlatest['category'].'/'.$rowlatest['media'];    ?> " alt="" style="border:1px;">
                            <span class="overlay"></span>
                        </a>
                        <figcaption>
                          <a href="single_page.php?newsid=<?php echo $rowlatest['wid']; ?>"> <?php echo $rowlatest['title'];    ?> </a>
                        </figcaption>
                          <p><?php echo $rowlatest['description'];    ?></p>
                      </figure>
                    </li>
         
        
            <?php  } }   ?>
                  

                  </ul>



                  <ul class="spost_nav">
                       <?php $sqllatest = "SELECT *,wrs.id as wid FROM world_rss as wrs left join category as catg  on wrs.category_id=catg.id where catg.category='politics' ORDER BY UNIX_TIMESTAMP(datetime) DESC limit 0,5 ";
                               
            $resultlatest = $conn->query($sqllatest);	
            $resultlatest->num_rows; 

            if ($resultlatest->num_rows > 0) {							
            $incre_num = 1;

            foreach($resultlatest as $rowlatest) {  ?>
                    
               <li>
                    <div class="media wow fadeInDown">
                      <a href="single_page.php?newsid=<?php echo $rowlatest['wid']; ?>" class="media-left">
                        <img src="/images/<?php echo $rowlatest['category'].'/'.$rowlatest['media'];    ?> " alt="" style="border:1px;">
                      </a>
                      <div class="media-body">
                        <a href="single_page.php?newsid=<?php echo $rowlatest['wid']; ?>" class="catg_title"> <?php echo $rowlatest['title'];    ?></a>                        
                      </div>
                    </div>
                  </li>
                        
        
            <?php  } }   ?>
                  
                  </ul>
                </div>
              </div>
            </div>
            <!-- End 2 style category design -->
            <!-- start photography stye design -->
            <div class="single_post_content">
              <h2><span>Photography</span></h2>
              <ul class="photograph_nav  wow fadeInDown">   
                   <?php  $sqllatest = "SELECT *,wrs.id as wid FROM world_rss as wrs left join category as catg  on wrs.category_id=catg.id where catg.category='photography' ORDER BY UNIX_TIMESTAMP(datetime) DESC limit 0,5 ";
                               
            $resultlatest = $conn->query($sqllatest);	
            $resultlatest->num_rows; 

            if ($resultlatest->num_rows > 0) {							
            $incre_num = 1;

            foreach($resultlatest as $rowlatest) {  ?>
                <li>
                  <div class="photo_grid">
                    <figure class="effect-layla">
                   <a class="fancybox-buttons" data-fancybox-group="button" href="single_page.php?newsid=<?php echo $rowlatest['wid']; ?>" class="catg_title" title="Photography Ttile 1">
                     <img src="/images/<?php echo $rowlatest['category'].'/'.$rowlatest['media'];    ?> " alt="" style="border:1px;"></a>  
                    </figure>
                  </div>
                </li>
                
            <?php }} ?>      
                  
                
              </ul>            
            </div>
            <!-- End photography stye design -->
            <!-- start games category design -->
            <div class="single_post_content">
              <h2><span>Health</span></h2>
              <div class="single_post_content_left">
                <ul class="business_catgnav">


                  <?php $sqllatest = "SELECT *,wrs.id as wid FROM world_rss as wrs left join category as catg  on wrs.category_id=catg.id where catg.category='health' ORDER BY UNIX_TIMESTAMP(datetime) DESC limit 0,1 ";
                               
            $resultlatest = $conn->query($sqllatest);	
            $resultlatest->num_rows; 

            if ($resultlatest->num_rows > 0) {							
            $incre_num = 1;

            foreach($resultlatest as $rowlatest) {  ?>
                            
                  <li>
                    <figure class="bsbig_fig  wow fadeInDown">
                      <a class="featured_img" href="single_page.php?newsid=<?php echo $rowlatest['wid']; ?>">
                         <img src="/images/<?php echo $rowlatest['category'].'/'.$rowlatest['media'];    ?> " alt="" style="border:1px;">
                          <span class="overlay"></span>
                      </a>
                      <figcaption>
                        <a href="single_page.php?newsid=<?php echo $rowlatest['wid']; ?>"><?php echo $rowlatest['title'];   ?></a>
                      </figcaption>
                        <p><?php echo $rowlatest['description'];   ?></p>
                    </figure>
                  </li>          
                        
        
            <?php  } }   ?>
                

                </ul>
              </div>
              <div class="single_post_content_right">
                <ul class="spost_nav">

                 <?php $sqllatest = "SELECT *,wrs.id as wid FROM world_rss as wrs left join category as catg  on wrs.category_id=catg.id where catg.category='health' ORDER BY UNIX_TIMESTAMP(datetime)  DESC limit 0,5 ";
                               
            $resultlatest = $conn->query($sqllatest);	
            $resultlatest->num_rows; 

            if ($resultlatest->num_rows > 0) {							
            $incre_num = 1;

            foreach($resultlatest as $rowlatest) {  ?>
                    
               <li>
                    <div class="media wow fadeInDown">
                      <a href="single_page.php?newsid=<?php echo $rowlatest['wid']; ?>" class="media-left">
                        <img src="/images/<?php echo $rowlatest['category'].'/'.$rowlatest['media'];    ?> " alt="" style="border:1px;">
                      </a>
                      <div class="media-body">
                        <a href="single_page.php?newsid=<?php echo $rowlatest['wid']; ?>" class="catg_title"> <?php echo $rowlatest['title'];   ?></a>                        
                      </div>
                    </div>
                  </li>              
                        
        
            <?php  } }   ?>
                  

                </ul>
              </div>
            </div>
            <!-- End games category design -->            
          </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-4">
          <aside class="right_content">
            <div class="single_sidebar">
              <h2><span>Popular Post</span></h2>
              <ul class="spost_nav">
                <li>
                  <div class="media wow fadeInDown">
                    <a href="single_page.html" class="media-left">
                      <img alt="img" src="img/post_img1.jpg">
                    </a>
                    <div class="media-body">
                      <a href="single_page.php?newsid=<?php echo $rowlatest['wid']; ?>" class="catg_title"> Aliquam malesuada diam eget turpis varius 1</a>                        
                    </div>
                  </div>
                </li>
                <li>
                  <div class="media wow fadeInDown">
                    <a href="single_page.php?newsid=<?php echo $rowlatest['wid']; ?>" class="media-left">
                      <img alt="img" src="img/post_img2.jpg">
                    </a>
                    <div class="media-body">
                      <a href="single_page.php?newsid=<?php echo $rowlatest['wid']; ?>" class="catg_title"> Aliquam malesuada diam eget turpis varius 2</a>                        
                    </div>
                  </div>
                </li>
                <li>
                  <div class="media wow fadeInDown">
                    <a href="single_page.html" class="media-left">
                      <img alt="img" src="img/post_img1.jpg">
                    </a>
                    <div class="media-body">
                      <a href="single_page.html" class="catg_title"> Aliquam malesuada diam eget turpis varius 3</a>                        
                    </div>
                  </div>
                </li>
                <li>
                  <div class="media wow fadeInDown">
                    <a href="single_page.html" class="media-left">
                      <img alt="img" src="img/post_img2.jpg">
                    </a>
                    <div class="media-body">
                      <a href="single_page.html" class="catg_title"> Aliquam malesuada diam eget turpis varius 4</a>                       
                    </div>
                  </div>
                </li>
              </ul>
            </div>
            <!-- start tab section -->
            <div class="single_sidebar">
               <!-- Nav tabs -->
              <ul class="nav nav-tabs" role="tablist">
                <li role="presentation" class="active"><a href="#category" aria-controls="home" role="tab" data-toggle="tab">Category</a></li>
                <li role="presentation"><a href="#video" aria-controls="profile" role="tab" data-toggle="tab">Video</a></li>
                <li role="presentation"><a href="#comments" aria-controls="messages" role="tab" data-toggle="tab">Comments</a></li>               
              </ul>
              <div class="tab-content">
                <div role="tabpanel" class="tab-pane active" id="category">
                  <ul>
                    <li class="cat-item"><a href="category.php?cat_id=">Sports</a></li>
                    <li class="cat-item"><a href="#">Fashion</a></li>
                    <li class="cat-item"><a href="category.php?cat_id=2">Business</a></li>
                    <li class="cat-item"><a href="category.php?cat_id=6">Technology</a></li>
                    <li class="cat-item"><a href="#">Games</a></li>
                    <li class="cat-item"><a href="category.php?cat_id=">Life & Style</a></li>
                    <li class="cat-item"><a href="category.php?cat_id=7">Photography</a></li>
                  
                  </ul>
                </div>
                <div role="tabpanel" class="tab-pane" id="video">
                  <div class="vide_area">                   
                    <iframe width="100%" height="250" src="http://www.youtube.com/embed/h5QWbURNEpA?feature=player_detailpage" frameborder="0" allowfullscreen></iframe>
                  </div>
                </div>
                <div role="tabpanel" class="tab-pane" id="comments">
                  <ul class="spost_nav">
                <li>
                  <div class="media wow fadeInDown">
                    <a href="single_page.html" class="media-left">
                      <img alt="img" src="img/post_img1.jpg">
                    </a>
                    <div class="media-body">
                      <a href="single_page.html" class="catg_title"> Aliquam malesuada diam eget turpis varius 1</a>                        
                    </div>
                  </div>
                </li>
                <li>
                  <div class="media wow fadeInDown">
                    <a href="single_page.html" class="media-left">
                      <img alt="img" src="img/post_img2.jpg">
                    </a>
                    <div class="media-body">
                      <a href="single_page.html" class="catg_title"> Aliquam malesuada diam eget turpis varius 2</a>                        
                    </div>
                  </div>
                </li>
                <li>
                  <div class="media wow fadeInDown">
                    <a href="single_page.html" class="media-left">
                      <img alt="img" src="img/post_img1.jpg">
                    </a>
                    <div class="media-body">
                      <a href="single_page.html" class="catg_title"> Aliquam malesuada diam eget turpis varius 3</a>                        
                    </div>
                  </div>
                </li>
                <li>
                  <div class="media wow fadeInDown">
                    <a href="single_page.html" class="media-left">
                      <img alt="img" src="img/post_img2.jpg">
                    </a>
                    <div class="media-body">
                      <a href="single_page.html" class="catg_title"> Aliquam malesuada diam eget turpis varius 4</a>                       
                    </div>
                  </div>
                </li>
              </ul>
                </div>
              </div>            
            </div>
            <!-- End tab section -->
            <!-- sponsor add -->
            <div class="single_sidebar wow fadeInDown">
              <h2><span>Sponsor</span></h2>
              <a class="sideAdd" href="#"><img src="img/add_img.jpg" alt="img"></a>
            </div>
            <!-- End sponsor add -->
             <!-- Category Archive -->
            <div class="single_sidebar wow fadeInDown">
              <h2><span>Category Archive</span></h2>
              <select class="catgArchive">
                <option>Select Category</option>
                <option>Life styles</option>
                <option>Sports</option>
                <option>Technology</option>
                <option>Treads</option>
              </select>
            </div>
            <!-- End category Archive -->
              <!-- sponsor add -->
            <div class="single_sidebar wow fadeInDown">
              <h2><span>Links</span></h2>
              <ul>
                <li><a href="#">Blog</a></li>
                <li><a href="#">Rss Feed</a></li>
                <li><a href="#">Login</a></li>
                <li><a href="#">Life & Style</a></li>
              </ul>
            </div>
            <!-- End sponsor add -->
          </aside>
        </div>
      </div>  
    </section>
    <!-- ==================End content body section=============== -->    
    <footer id="footer">       
      <div class="footer_top">
        <div class="row">
          <div class="col-lg-4 col-md-4 col-sm-4">
            <div class="footer_widget wow fadeInLeftBig">
              <h2>Flickr Images</h2>
                       
            </div>
          </div>
          <div class="col-lg-4 col-md-4 col-sm-4">
            <div class="footer_widget wow fadeInDown">
              <h2>Tag</h2>
              <ul class="tag_nav">
                <li><a href="#">Games</a></li>
                <li><a href="#">Sports</a></li>
                <li><a href="#">Fashion</a></li>
                <li><a href="#">Business</a></li>
                <li><a href="#">Life & Style</a></li>
                <li><a href="#">Technology</a></li>
                <li><a href="#">Photo</a></li>
                <li><a href="#">Slider</a></li>
              </ul>              
            </div>
          </div>
          <div class="col-lg-4 col-md-4 col-sm-4">
            <div class="footer_widget wow fadeInRightBig">
              <h2>Contact</h2>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
              <address>
                Perfect News,1238 S . 123 St.Suite 25 Town City 3333,USA Phone: 123-326-789 Fax: 123-546-567 
              </address>              
            </div>
          </div>
        </div>
      </div>       
      <div class="footer_bottom">
        <p class="copyright">
          All Rights Reserved <a href="home.html">NewsFeed</a>
        </p>
        <p class="developer">Developed By <a href=""></a></p>
      </div>    
    </footer>
  </div> <!-- /.container -->
  

  <!-- jQuery Library -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script> 
  <!-- For content animatin  -->
  <script src="js/wow.min.js"></script>
  <!-- bootstrap js file -->
  <script src="js/bootstrap.min.js"></script> 
  <!-- slick slider js file -->
  <script src="js/slick.min.js"></script> 
  <!-- news ticker jquery file -->
  <script src="js/jquery.li-scroller.1.0.js"></script>
  <!-- for news slider -->
  <script src="js/jquery.newsTicker.min.js"></script>
  <!-- for fancybox slider -->
  <script src="js/jquery.fancybox.pack.js"></script>
  <!-- custom js file include -->    
  <script src="js/custom.js"></script> 
 

  <!-- =========================
        //////////////This Theme Design and Developed //////////////////////
        //////////// by www.wpfreeware.com======================-->
    
      
  </body>
</html>
