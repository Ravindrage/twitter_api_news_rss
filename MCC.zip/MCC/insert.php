<?php

//ini_set('display_errors',1);
//ini_set('log_errors',1);
//var_dump(ini_get('allow_url_fopen'));
error_reporting(E_ERROR | E_WARNING | E_PARSE);


include("connection.php");
global $conn;

$sql = "SELECT * FROM category ";
$result = $conn->query($sql);
	
$result->num_rows; 

if ($result->num_rows > 0) {							
$incre_num = 1;

foreach($result as $row) {   
               
$rss = simplexml_load_file($row['url']);
$i=0;
    
foreach($rss->channel->item as $item) {
    
     $title = (string)$item->title[0];  echo '</br>';
     $description = (string)$item->description[0];  echo '</br>';
     $link = $item->link;  echo '</br>';
     $guid = $item->guid;  echo '</br>';
     $pubDate = $item->pubDate; echo '</br>';
    
    
     $namespaces = $item->getNamespaces(true);
    // var_dump($namespaces);
    
    //echo $media  = $item->media;   echo '</br>';
       //print_r($item);
    
    foreach($item as $attribute){
        //print_r($attribute);
         $attribute->children('@attribute', true)->url;
        //print_r($attribute['@attribute']);
       // echo $attribute['@attribute']['url'];
        $media1=  $attribute['url'];
    }
    
    
    
    $thumbAttr = $item->children('media', true)->thumbnail->attributes();
    // or preferably the namespace name, read note below for an explanation
    
    $thumbAttr = $item->children('http://search.yahoo.com/mrss/')->thumbnail->attributes();
    
    // $thumbAttr;
    
    if(empty($thumbAttr))
    { 
      $thumbAttr = trim((string)$item->children($namespaces['media'])->content->attributes()->url);
      echo $media = $thumbAttr; 
      
        
    } else{    
     $media = $thumbAttr['url']; echo '</br>'; 
    }
    //echo '</br>';
     $i++; 
     $imagename = basename($media); //echo "  ";
    
     $_SERVER['DOCUMENT_ROOT'];

     $row['category']; echo '</br>';

      
    
    $category_id = $row['id'] ; 
    $descriptionn = str_replace('"', '', $description); 
    $titlen = str_replace('"', '', $title); 

    $sql123 = 'SELECT * FROM world_rss  where category_id = "'.$category_id.'" and title = "'.$titlen.'" ';
    $result123 = $conn->query($sql123);	
          
/*if ($result123->num_rows > 0) {	
    }else
    {*/
      $path_parts = pathinfo($media);
      $etens = $path_parts['extension'] ;
      $newstring = substr($titlen, -7);
    
      if($etens!='png' && $etens!='jpg' && $etens!='bmp' && $etens!='gif' )
        {
          $imagename = $newstring.'.jpg';
        }
    
    if(!copy($media,'images/'.$row['category'].'/'.$imagename)){
       $row['category'];    
       $media1;  
          
        
      $imagename = basename($media1);  
      $path_parts = pathinfo($media1);    
      $imagename1 = $path_parts['filename']; 
      $path_parts = pathinfo($imagename1); 
      $etens1 = $path_parts['extension'] ;    
        
    if($etens1!='png' && $etens1!='jpg' && $etens1!='bmp' && $etens1!='gif' )
      { echo $imagename = $imagename1.'.jpg'; }
        echo $media1;
      copy($media1,'images/'.$row['category'].'/'.$imagename);
      }
    
    
      
    
    if(!isset($media) and empty($media))
    {
     $media = $media1;
    }
    
  
     $sql = 'Insert into world_rss(title,description,link,guid,pubDate,media,category_id,datetime) values   ("'.$titlen.'","'.$descriptionn.'","'.$link.'","'.$guid.'","'.$pubDate.'","'.$imagename.'","'.$category_id.'",now())';  
 
     $result = $conn->query($sql) ;

    //}
             
   }
    
}
    
}



?>
