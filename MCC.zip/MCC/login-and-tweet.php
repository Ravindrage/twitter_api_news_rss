<?php

ini_set('display_errors', 1); 

require_once ('codebird/src/codebird.php');
\Codebird\Codebird::setConsumerKey('3SnRMfhwhIefEwhqPFkZpOEZT','rVf3rBunw7TK0yVnWRrYNoo9s1cQKmTiY3ghZjXgdH1eFGrCAF'); // static, see README

$cb = \Codebird\Codebird::getInstance();

$cb->setToken('762576996958343168-k4sc02q3aUyHfD8Fe5USNT83lJxZQhj', '2s6dLqM4x9IbBYoXr37Ab4L0QK2AGWxDS8TV2qQ6usruR');

session_start();

if (! isset($_SESSION['oauth_token'])) {
  // get the request token
  $reply = $cb->oauth_requestToken([
    'oauth_callback' => 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']
  ]);

  // store the token
  $cb->setToken($reply->oauth_token, $reply->oauth_token_secret);
  $_SESSION['oauth_token'] = $reply->oauth_token;
  $_SESSION['oauth_token_secret'] = $reply->oauth_token_secret;
  $_SESSION['oauth_verify'] = true;

  // redirect to auth website
  $auth_url = $cb->oauth_authorize();
  header('Location: ' . $auth_url);
  die();

} elseif (isset($_GET['oauth_verifier']) && isset($_SESSION['oauth_verify'])) {
  // verify the token
  $cb->setToken($_SESSION['oauth_token'], $_SESSION['oauth_token_secret']);
  unset($_SESSION['oauth_verify']);

  // get the access token
  $reply = $cb->oauth_accessToken([
    'oauth_verifier' => $_GET['oauth_verifier']
  ]);

  // store the token (which is different from the request token!)
  $_SESSION['oauth_token'] = $reply->oauth_token;
  $_SESSION['oauth_token_secret'] = $reply->oauth_token_secret;

  // send to same URL, without oauth GET parameters
  header('Location: ' . basename(__FILE__));
  die();
}

echo 'hello';
// assign access token on each page load
$cb->setToken($_SESSION['oauth_token'], $_SESSION['oauth_token_secret']);

//$reply = (array) $cb->statuses_homeTimeline();
//print_r($reply);

$reply = $cb->statuses_update('status=Whohoo, I just Tweeted!');


?>
