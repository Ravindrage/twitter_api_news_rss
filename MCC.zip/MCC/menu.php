<?php include("connection.php"); ?>
<header id="header">    
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12">
          <div class="header_top">
            <div class="header_top_left">
              <ul class="top_nav">
                <li><a href="#">Home</a></li>
                <li><a href="#">About</a></li>
                <li><a href="#">Contact</a></li>
              </ul>
            </div>
            <div class="header_top_right">
              <p><?php echo date("F j, Y"); ?></p>
            </div>
          </div>
        </div>
        <div class="col-lg-12 col-md-12 col-sm-12">
          <div class="header_bottom">
            <div class="logo_area">
              <!-- for your img logo format
              <a href="home.html" class="logo">
                <img src="img/logo.jpg" alt="logo">
                
              </a> -->
              <!-- for your text logo format -->
               <a href="#" class="logo">
                Tesco <span>press</span>
              </a> 
            </div>
            <div class="add_banner">
              <a<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- footers -->
<ins class="adsbygoogle"
     style="display:inline-block;width:728px;height:90px"
     data-ad-client="ca-pub-9563089652950762"
     data-ad-slot="6929640025"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script></a>
            </div>
          </div>
        </div>
      </div>  
</header>

<section id="navArea">
      <!-- Start navbar -->
      <nav class="navbar navbar-inverse" role="navigation">      
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>          
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav main_nav">
            <li class="active"><a href="index.php"><span class="fa fa-home desktop-home"></span><span class="mobile-show">Home</span></a></li>
            <li><a href="category.php?cat_id=6">Technology</a></li>            
            <li class="dropdown">
              <a href="category.php?cat_id=2" >Business</a>
             </li>
            <li><a href="category.php?cat_id=5">Education & Family</a></li> 
            <li><a href="category.php?cat_id=3">Politics</a></li>  
            <li><a href="category.php?cat_id=7">Photography</a></li>
            <li><a href="category.php?cat_id=4">Health</a></li>
            <li><a href="/sport">Sport</a></li>
          </ul>           
        </div><!--/.nav-collapse -->      
      </nav>
    </section><!-- End nav section -->
	<section id="newsSection">
      <div class="row">
        <div class="col-lg-12 col-md-12">
           <!-- start news sticker -->
          <div class="latest_newsarea">      
            <span>Latest News</span>
            <ul id="ticker01" class="news_sticker">
                
            <?php $sqllatest = "SELECT *,wrs.id as wid FROM world_rss as wrs left join category as catg  on wrs.category_id=catg.id  group by category_id  ORDER BY UNIX_TIMESTAMP(datetime) DESC";
                               
            $resultlatest = $conn->query($sqllatest);	
            $resultlatest->num_rows; 

            if ($resultlatest->num_rows > 0) {							
            $incre_num = 1;

            foreach($resultlatest as $rowlatest) {  ?>

            <li><a href="single_page.php?newsid=<?php echo $rowlatest['wid']; ?>"><img src="/images/<?php echo $rowlatest['category'].'/'.$rowlatest['media'];    ?> " alt=""><?php echo $rowlatest['title'];    ?></a></li> 
            <?php  } }   ?>
             
             </ul>
            <div class="social_area">
              <ul class="social_nav">
                <li class="facebook"><a href="#"></a></li>
                <li class="twitter"><a href="#"></a></li>
                <li class="flickr"><a href="#"></a></li>
                <li class="pinterest"><a href="#"></a></li>
                <li class="googleplus"><a href="#"></a></li>
                <li class="vimeo"><a href="#"></a></li>
                <li class="youtube"><a href="#"></a></li>
                <li class="mail"><a href="mailto:info@smartnews.com"></a></li>
              </ul>
            </div>      
          </div><!-- End news sticker -->
        </div>
      </div>
    </section>
	
