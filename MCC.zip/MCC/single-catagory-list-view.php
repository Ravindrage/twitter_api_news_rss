<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width">

        <!-- plugin-->

        <!-- basic-->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/main.css">
        <link rel="stylesheet" href="css/widget.css">
        <link rel="stylesheet" href="css/layout.css">

        <!-- modules-->
        <link rel="stylesheet" href="css/modules/form.css">
        <link rel="stylesheet" href="css/modules/media.css">

        <!-- layouts-->
        <link rel="stylesheet" href="css/layouts/card.css">

        <script src="js/vendor/modernizr-2.6.2-respond-1.1.0.min.js"></script>
    </head>
    <body class="single-page">
      <?php

      include("connection.php");
      global $conn;

      ?>
    <?php


     include("menu.php");  ?>

    <div class="container full-page">
      <div class="row">

        <!-- <div class="banner-view widget">
          <img src="img/ad.jpg" alt="">
        </div> -->

        <div class="breadcrumb-wrapper">
          <ol class="breadcrumb">
            <li><a href="#">Home</a></li>
            <li class="active">Travel</li>
          </ol>
        </div><!--/breadcrumb-wrapper-->


        <div class="post-container container">

          <div class="col-md-9 list-view-post-format post-view content">

            <header class="page-header">
                <div class="page-title">
                  <h2 class="title"><div id="title"> </div></h2>
                </div>
              </header>

            <div class="post margin-top-20 clearfix">

              <div class="row">


                               <?php
                               if(isset($_REQUEST['cat']) )
                               {
                                  $sqllatest = "SELECT * FROM world_rss as wrs left join category as catg  on wrs.category_id=catg.id where catg.id = '".$_REQUEST['cat']."' ";
                                  $resultlatest = $conn->query($sqllatest);

                               if ($resultlatest->num_rows > 0) {

                                          $incre_num = 1;

                                          foreach($resultlatest as $rowlatest) {

                                        $image = 'http://whatsmyip.tech/images/'.$rowlatest['category'].'/'.$rowlatest['media'] ;
                                        $title = $rowlatest['title'];
                                        $description = $rowlatest['description'];
                                        $newsurl = $rowlatest['guid'];
                                        $category = $rowlatest['category_id'];
                                        $link =  $rowlatest['link'];
                                 ?>

               <div class="list-item clearfix">
                 <div class="list-thumbnail col-md-4">
                   <img src="<?php echo $image; ?>" alt="">
                 </div>
                 <div class="list-inner col-md-8">
                   <h4 class="title">
                     <a href="single.php?newsid=<?php echo $rowlatest['wid']; ?>"><?php echo $title;  ?></a>
                   </h4>
                   <div class="meta-wrapper">
                      <span class="meta"><i class="fa fa-calendar"></i> <?php echo $rowlatest['datetime']; ?></span>
                      <span class="meta"><i class="fa fa-comment-o"></i> 10</span>
                      <span class="meta"><i class="fa fa-share-square-o"></i> 3</span>
                    </div>
                   <p><?php echo $description; ?></p>
                 </div>
               </div><!--/list-item-->
              <script> document.getElementById('title').innerHTML = <?php echo $rowlatest['category']; ?> </script>
               <?php
                          }      }       }
                ?>




              </div>

              <footer class="page-footer clearfix">

                <ul class="pagination">
                  <li>Pages:</li>
                  <li class="active"><a href="#">1</a></li>
                  <li><a href="#">2</a></li>
                  <li><a href="#">3</a></li>
                  <li><a href="#">4</a></li>
                </ul>

              </footer>

            </div><!--/post-->


          </div><!--/news-post-format-->

          <aside class="col-md-3 sidebar">

            <div class="widget">
              <header class="widget-header">
                <h4 class="title">
                  Opinion
                </h4>
              </header>
              
            </div><!--/widget list-->

            <div class="widget form-view vote">
              <header class="widget-header">
                <h4 class="title">
                  QUICK VOTE
                </h4>
              </header>
              <div class="widget-content">
                <p class="margin-top-20">
                  Have you ever experienced rowdiness among other passengers on an airliner?
                </p>
                <form action="" class="form">
                  <div class="radio form-group radio-inline-group">
                    <label class="radio-inline iconlabel-wrapper ">
                      <input type="radio" name="optionsRadios" id="optionsRadios1" value="option1" checked>
                      <span class="radio-iconlabel"></span>Yes
                    </label>
                    <label class="radio-inline iconlabel-wrapper ">
                      <input type="radio" name="optionsRadios" id="optionsRadios1" value="option1" checked>
                      <span class="radio-iconlabel"></span>No
                    </label>
                  </div>
                  <hr class="clearfix">
                   <button type="submit" class="btn">vote</button> or <button type="submit" class="btn btn-link">view results</button>
                </form>
              </div>
            </div><!--/vote-->

            <div class="widget">
              <header class="widget-header">
                <h4 class="title">
                  TRENDING NOW
                </h4>
              </header>
              <ul class="media list">
                <li class="media">
                  <div href="#" class="widget-thumbnail hover-thumbnail video-box">
                    <a href="#" class="media-object"><img src="img/11.jpg" alt=""></a>
                  </div>
                  <div class="media-body margin-top-10">
                    <h4 class="media-heading title">
                      <a href="#">Not your average steering wheel</a>
                    </h4>
                    <p>Explore our interactive of one of F1's most important and complicated pieces of kit.</p>
                  </div>
                </li>
              </ul>
            </div>

          </aside>

        </div><!--/post-view-->

      </div><!--/full-page-->
    </div><!-- /main-view -->

    <div class="site-bottom hidden-xs">
      <div class="container">
        <div class="row">

          <div class="col-md-2 col-sm-4">
            <div class="widget footer-widget">
              <header class="widget-header">
                <h4 class="title">
                  ABOUT NCC theme
                </h4>
              </header>
              <div class="widget-content">
                <ul class="list list-view">
                  <li><a href="#">Theme style</a></li>
                  <li><a href="#">Page information</a></li>
                  <li><a href="#">RWD design</a></li>
                  <li><a href="#">Clean and easy to use</a></li>
                </ul>
              </div>
              <header class="widget-header">
                <h4 class="title">
                  SITE SERVICe
                </h4>
              </header>
              <div class="widget-content">
                <ul class="list list-view">
                  <li><a href="#">Promo Events</a></li>
                  <li><a href="#">Sweepstakes</a></li>
                  <li><a href="#">Newsletter</a></li>
                </ul>
              </div>
            </div>
          </div>

          <div class="col-md-2 col-sm-4">
            <div class="widget footer-widget">
              <header class="widget-header">
                <h4 class="title">
                  BUSINESS
                </h4>
              </header>
              <div class="widget-content">
                <ul class="list list-view">
                  <li><a href="#">The gateway</a></li>
                  <li><a href="#">Business Traveller</a></li>
                  <li><a href="#">Leading Women</a></li>
                  <li><a href="#">Companies News</a></li>
                  <li><a href="#">Markets News</a></li>
                  <li><a href="#">NCC Money</a></li>
                  <li><a href="#">NCC TW</a></li>
                </ul>
              </div>
            </div>
          </div>

          <div class="col-md-2 col-sm-4">
            <div class="widget footer-widget">
              <header class="widget-header">
                <h4 class="title">
                  WORLD
                </h4>
              </header>
              <div class="widget-content">
                <ul class="list list-view">
                  <li><a href="#">On the Road</a></li>
                  <li><a href="#">Celebrates</a></li>
                  <li><a href="#">Security Clearance</a></li>
                  <li><a href="#">Girl Rising</a></li>
                  <li><a href="#">NCC affiliates</a></li>
                  <li><a href="#">Asia</a></li>
                  <li><a href="#">Americas</a></li>
                  <li><a href="#">Europe</a></li>
                  <li><a href="#">Africa</a></li>
                  <li><a href="#">Middle East</a></li>
                  <li><a href="#">Around the web</a></li>
                </ul>
              </div>
            </div>
          </div>

          <div class="col-md-2 col-sm-4">
            <div class="widget footer-widget">
              <header class="widget-header">
                <h4 class="title">
                  SPORT
                </h4>
              </header>
              <div class="widget-content">
                <ul class="list list-view">
                  <li><a href="#">Winter Games</a></li>
                  <li><a href="#">Tennis</a></li>
                  <li><a href="#">Golf</a></li>
                  <li><a href="#">Skiing</a></li>
                  <li><a href="#">Motorsport</a></li>
                  <li><a href="#">Football</a></li>
                  <li><a href="#">Hores racing</a></li>
                  <li><a href="#">Sailing</a></li>
                  <li><a href="#">Bleacher Report</a></li>
                </ul>
              </div>
            </div>
          </div>

          <div class="col-md-2 col-sm-4">
            <div class="widget footer-widget">
              <header class="widget-header">
                <h4 class="title">
                  entertainment
                </h4>
              </header>
              <div class="widget-content">
                <ul class="list list-view">
                  <li><a href="#">Quote board</a></li>
                  <li><a href="#">Best of 2013</a></li>
                  <li><a href="#">Showbiz tonight</a></li>
                  <li><a href="#">Fall entertainment 2013</a></li>
                  <li><a href="#">Photo gallery</a></li>
                  <li><a href="#">Music</a></li>
                  <li><a href="#">Let's talk tv</a></li>
                </ul>
              </div>
            </div>
          </div>

          <div class="col-md-2 col-sm-4">
            <div class="widget footer-widget">
              <header class="widget-header">
                <h4 class="title">
                  Technology
                </h4>
              </header>
              <div class="widget-content">
                <ul class="list list-view">
                  <li><a href="#">Socail media</a></li>
                  <li><a href="#">Mobile</a></li>
                  <li><a href="#">Web</a></li>
                  <li><a href="#">Gaming & Gadgets</a></li>
                  <li><a href="#">Innovation</a></li>
                  <li><a href="#">Tech biz</a></li>
                </ul>
              </div>
            </div>
          </div>


        </div>
      </div>
    </div><!--/site-bottom-->

    <footer class="site-footer">
      <div class="container footer-view">
        <div class="row">

          <div class="col-md-6 col-sm-6 copyright">
            <span>Copyright 2014 © NCC Magazine. </span>
          </div>

          <div class="col-md-6 col-sm-6 footer-link">
            <ul class="menu">
              <li><a href="#">TERMS OF US</a></li>
              <li><a href="#">PRIVACY POLICY</a></li>
            </ul>
          </div>

        </div><!--/footer-view .row-->
      </div><!--/footer-view-->
    </footer><!--/site-footer-->

        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>

        <script>window.jQuery || document.write('<script src="js/vendor/jquery-1.10.1.min.js"><\/script>')</script>

        <script src="js/vendor/bootstrap.min.js"></script>

        <!-- plugin js-->
        <script src="js/jquery.bxslider.min.js"></script>

        <script src="js/main.js"></script>

    </body>
</html>
