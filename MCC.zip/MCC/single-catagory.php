<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width">

        <!-- plugin-->

        <!-- basic-->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/main.css">
        <link rel="stylesheet" href="css/widget.css">
        <link rel="stylesheet" href="css/layout.css">

        <!-- modules-->
        <link rel="stylesheet" href="css/modules/form.css">
        <link rel="stylesheet" href="css/modules/media.css">

        <!-- layouts-->
        <link rel="stylesheet" href="css/layouts/card.css">

        <script src="js/vendor/modernizr-2.6.2-respond-1.1.0.min.js"></script>
    </head>
    <body class="single-page">


    <div class="container full-page">
      <div class="row">

        <!-- <div class="banner-view widget">
          <img src="img/ad.jpg" alt="">
        </div> -->

        <div class="breadcrumb-wrapper">
          <ol class="breadcrumb">
            <li><a href="#">Home</a></li>
            <li class="active">Travel</li>
          </ol>
        </div><!--/breadcrumb-wrapper-->


        <div class="post-container container">

          <div class="col-md-9 card-post-format post-view content">

            <header class="page-header">
                <div class="page-title">
                  <h2 class="title">Travel</h2>
                </div>
              </header>

            <div class="feature-view">
              <div class="card-thumbnail">
                 <img src="img/travel_11.jpg" alt="">
                 <div class="card-meta">
                   <ul class="list">
                     <li><a href="#"><i class="fa fa-heart"></i>121</a></li>
                     <li><a href="#"><i class="fa fa-comment"></i>320</a></li>
                   </ul>
                 </div>
              </div>
              <div class="col-inner">
                 <h4 class="title">
                   <a href="#">15 lesser-known ski resorts to check out this winter</a>
                 </h4>
                 <p>This month, CNNGo visits South Africa's largest city and one of its most exciting -- home to radical theater, apartheid relics and a museum of beer.This month, CNNGo visits South Africa's largest city and one of its most exciting -- home to radical theater, apartheid </p>
               </div>
            </div>

            <div class="post margin-top-20 clearfix">

              <div class="row">

               <div class="col-md-4 card-item">
                 <div class="card-thumbnail">
                   <img src="img/travel_1.jpg" alt="">
                   <div class="card-meta">
                     <ul class="list">
                       <li><a href="#"><i class="fa fa-heart"></i>12</a></li>
                       <li><a href="#"><i class="fa fa-comment"></i>3</a></li>
                     </ul>
                   </div>
                 </div>
                 <div class="col-inner card-">
                   <h4 class="title">
                     <a href="#">15 lesser-known ski resorts to check out this winter</a>
                   </h4>
                   <p>This month, CNNGo visits South Africa's largest city and one of its most exciting -- home to radical theater, apartheid relics and a museum of beer.</p>
                 </div>
               </div><!--/card-item-->

               <?php
               if(isset($_REQUEST['cat']) )
               {
                  $sqllatest = "SELECT * FROM world_rss where category_id = '".$_REQUEST['cat']."' ";
                  $resultlatest = $conn->query($sqllatest);

               if ($resultlatest->num_rows > 0) {

                          $incre_num = 1;

                          foreach($resultlatest as $rowlatest) {

                        $image = 'http://whatsmyip.tech/images/'.$rowlatest['category'].'/'.$rowlatest['media'] ;
                        $title = $rowlatest['title'];
                        $description = $rowlatest['description'];
                        $newsurl = $rowlatest['guid'];
                        $category = $rowlatest['category_id'];
                        $link =  $rowlatest['link'];
                 ?>

               <div class="col-md-4 card-item">
                 <div class="card-thumbnail">
                   <img src="<?php echo $image; ?>" alt="">
                   <div class="card-meta">
                     <ul class="list">
                       <li><a href="#"><i class="fa fa-heart"></i>33</a></li>
                       <li><a href="#"><i class="fa fa-comment"></i>11</a></li>
                     </ul>
                   </div>
                 </div>
                 <div class="col-inner">
                   <h4 class="title">
                     <a href="#"><?php echo $title;  ?></a>
                   </h4>
                   <p><?php echo $description; ?></p>
                 </div>
               </div><!--/card-item-->

<?php
           }      }       }
 ?>



               <div class="col-md-4 card-item">
                 <div class="card-thumbnail">
                   <img src="img/travel_4.jpg" alt="">
                   <div class="card-meta">
                     <ul class="list">
                       <li><a href="#"><i class="fa fa-heart"></i>82</a></li>
                       <li><a href="#"><i class="fa fa-comment"></i>11</a></li>
                     </ul>
                   </div>
                 </div>
                 <div class="col-inner">
                   <h4 class="title">
                     <a href="#">15 lesser-known ski resorts to check out this winter</a>
                   </h4>
                   <p>This month, CNNGo visits South Africa's largest city and one of its most exciting -- home to radical theater, apartheid relics and a museum of beer.</p>
                 </div>
               </div><!--/card-item-->
               <div class="col-md-4 card-item">
                 <div class="card-thumbnail">
                   <img src="img/travel_5.jpg" alt="">
                   <div class="card-meta">
                     <ul class="list">
                       <li><a href="#"><i class="fa fa-heart"></i>0</a></li>
                       <li><a href="#"><i class="fa fa-comment"></i>3</a></li>
                     </ul>
                   </div>
                 </div>
                 <div class="col-inner">
                   <h4 class="title">
                     <a href="#">15 lesser-known ski resorts to check out this winter</a>
                   </h4>
                   <p>This month, CNNGo visits South Africa's largest city and one of its most exciting -- home to radical theater, apartheid relics and a museum of beer.</p>
                 </div>
               </div><!--/card-item-->
               <div class="col-md-4 card-item">
                 <div class="card-thumbnail">
                   <img src="img/travel_7.jpg" alt="">
                   <div class="card-meta">
                     <ul class="list">
                       <li><a href="#"><i class="fa fa-heart"></i>4</a></li>
                       <li><a href="#"><i class="fa fa-comment"></i>13</a></li>
                     </ul>
                   </div>
                 </div>
                 <div class="col-inner">
                   <h4 class="title">
                     <a href="#">15 lesser-known ski resorts to check out this winter</a>
                   </h4>
                   <p>This month, CNNGo visits South Africa's largest city and one of its most exciting -- home to radical theater, apartheid relics and a museum of beer.</p>
                 </div>
               </div><!--/card-item-->
               <div class="col-md-4 card-item">

                 <div class="card-thumbnail">
                   <img src="img/travel_8.jpg" alt="">
                   <div class="card-meta">
                     <ul class="list">
                       <li><a href="#"><i class="fa fa-heart"></i>9</a></li>
                       <li><a href="#"><i class="fa fa-comment"></i>3</a></li>
                     </ul>
                   </div>
                 </div>
                 <div class="col-inner">
                   <h4 class="title">
                     <a href="#">15 lesser-known ski resorts to check out this winter</a>
                   </h4>
                   <p>This month, CNNGo visits South Africa's largest city and one of its most exciting -- home to radical theater, apartheid relics and a museum of beer.</p>
                 </div>
               </div><!--/card-item-->
               <div class="col-md-4 card-item">
                 <div class="card-thumbnail">
                   <img src="img/travel_9.jpg" alt="">
                   <div class="card-meta">
                     <ul class="list">
                       <li><a href="#"><i class="fa fa-heart"></i>14</a></li>
                       <li><a href="#"><i class="fa fa-comment"></i>31</a></li>
                     </ul>
                   </div>
                 </div>
                 <div class="col-inner">
                   <h4 class="title">
                     <a href="#">15 lesser-known ski resorts to check out this winter</a>
                   </h4>
                   <p>This month, CNNGo visits South Africa's largest city and one of its most exciting -- home to radical theater, apartheid relics and a museum of beer.</p>
                 </div>
               </div><!--/card-item-->
               <div class="col-md-4 card-item">
                 <div class="card-thumbnail">
                   <img src="img/travel_10.jpg" alt="">
                   <div class="card-meta">
                     <ul class="list">
                       <li><a href="#"><i class="fa fa-heart"></i>121</a></li>
                       <li><a href="#"><i class="fa fa-comment"></i>223</a></li>
                     </ul>
                   </div>
                 </div>
                 <div class="col-inner">
                   <h4 class="title">
                     <a href="#">15 lesser-known ski resorts to check out this winter</a>
                   </h4>
                   <p>This month, CNNGo visits South Africa's largest city and one of its most exciting -- home to radical theater, apartheid relics and a museum of beer.</p>
                 </div>
               </div><!--/card-item-->


              </div>

              <footer class="page-footer clearfix">

                <ul class="pagination">
                  <li>Pages:</li>
                  <li class="active"><a href="#">1</a></li>
                  <li><a href="#">2</a></li>
                  <li><a href="#">3</a></li>
                  <li><a href="#">4</a></li>
                </ul>

              </footer>

            </div><!--/post-->


          </div><!--/news-post-format-->

          <aside class="col-md-3 sidebar">

            <div class="widget">
              <header class="widget-header">
                <h4 class="title">
                  Opinion
                </h4>
              </header>
              <div class="widget-content">
                <ul class="media-list list">
                  <li class="media">
                    <a href="#" class="pull-right">
                      <img src="img/avatar_1.jpg" alt="" class="media-object">
                    </a>
                    <div class="media-body">
                      <h4 class="media-heading title">
                        SUSAN MILLIGAN
                      </h4>
                      <p>UPS Delivers Christmas a Day Late</p>
                    </div>
                  </li>
                  <li class="media">
                    <a href="#" class="pull-right">
                      <img src="img/avatar_2.jpg" alt="" class="media-object">
                    </a>
                    <div class="media-body">
                      <h4 class="media-heading title">
                        CHARLES WHEELAN
                      </h4>
                      <p>Political Resolutions for 2014</p>
                    </div>
                  </li>
                  <li class="media">
                    <a href="#" class="pull-right">
                      <img src="img/avatar_3.jpg" alt="" class="media-object">
                    </a>
                    <div class="media-body">
                      <h4 class="media-heading title">
                        MORT ZUCKERMAN
                      </h4>
                      <p>Looking Back at 2013</p>
                    </div>
                  </li>
                  <li class="media">
                    <a href="#" class="pull-right">
                      <img src="img/avatar_4.jpg" alt="" class="media-object">
                    </a>
                    <div class="media-body">
                      <h4 class="media-heading title">
                        PETER ROFF
                      </h4>
                      <p>America Just Isn't That Into Obama Anymore</p>
                    </div>
                  </li>
                </ul>
              </div>
            </div><!--/widget list-->

            <div class="widget form-view vote">
              <header class="widget-header">
                <h4 class="title">
                  QUICK VOTE
                </h4>
              </header>
              <div class="widget-content">
                <p class="margin-top-20">
                  Have you ever experienced rowdiness among other passengers on an airliner?
                </p>
                <form action="" class="form">
                  <div class="radio form-group radio-inline-group">
                    <label class="radio-inline iconlabel-wrapper ">
                      <input type="radio" name="optionsRadios" id="optionsRadios1" value="option1" checked>
                      <span class="radio-iconlabel"></span>Yes
                    </label>
                    <label class="radio-inline iconlabel-wrapper ">
                      <input type="radio" name="optionsRadios" id="optionsRadios1" value="option1" checked>
                      <span class="radio-iconlabel"></span>No
                    </label>
                  </div>
                  <hr class="clearfix">
                   <button type="submit" class="btn">vote</button> or <button type="submit" class="btn btn-link">view results</button>
                </form>
              </div>
            </div><!--/vote-->

            <div class="widget">
              <header class="widget-header">
                <h4 class="title">
                  TRENDING NOW
                </h4>
              </header>
              <ul class="media list">
                <li class="media">
                  <div href="#" class="widget-thumbnail hover-thumbnail video-box">
                    <a href="#" class="media-object"><img src="img/11.jpg" alt=""></a>
                  </div>
                  <div class="media-body margin-top-10">
                    <h4 class="media-heading title">
                      <a href="#">Not your average steering wheel</a>
                    </h4>
                    <p>Explore our interactive of one of F1's most important and complicated pieces of kit.</p>
                  </div>
                </li>
              </ul>
            </div>

          </aside>

        </div><!--/post-view-->

      </div><!--/full-page-->
    </div><!-- /main-view -->

    <div class="site-bottom hidden-xs">
      <div class="container">
        <div class="row">

          <div class="col-md-2 col-sm-4">
            <div class="widget footer-widget">
              <header class="widget-header">
                <h4 class="title">
                  ABOUT NCC theme
                </h4>
              </header>
              <div class="widget-content">
                <ul class="list list-view">
                  <li><a href="#">Theme style</a></li>
                  <li><a href="#">Page information</a></li>
                  <li><a href="#">RWD design</a></li>
                  <li><a href="#">Clean and easy to use</a></li>
                </ul>
              </div>
              <header class="widget-header">
                <h4 class="title">
                  SITE SERVICe
                </h4>
              </header>
              <div class="widget-content">
                <ul class="list list-view">
                  <li><a href="#">Promo Events</a></li>
                  <li><a href="#">Sweepstakes</a></li>
                  <li><a href="#">Newsletter</a></li>
                </ul>
              </div>
            </div>
          </div>

          <div class="col-md-2 col-sm-4">
            <div class="widget footer-widget">
              <header class="widget-header">
                <h4 class="title">
                  BUSINESS
                </h4>
              </header>
              <div class="widget-content">
                <ul class="list list-view">
                  <li><a href="#">The gateway</a></li>
                  <li><a href="#">Business Traveller</a></li>
                  <li><a href="#">Leading Women</a></li>
                  <li><a href="#">Companies News</a></li>
                  <li><a href="#">Markets News</a></li>
                  <li><a href="#">NCC Money</a></li>
                  <li><a href="#">NCC TW</a></li>
                </ul>
              </div>
            </div>
          </div>

          <div class="col-md-2 col-sm-4">
            <div class="widget footer-widget">
              <header class="widget-header">
                <h4 class="title">
                  WORLD
                </h4>
              </header>
              <div class="widget-content">
                <ul class="list list-view">
                  <li><a href="#">On the Road</a></li>
                  <li><a href="#">Celebrates</a></li>
                  <li><a href="#">Security Clearance</a></li>
                  <li><a href="#">Girl Rising</a></li>
                  <li><a href="#">NCC affiliates</a></li>
                  <li><a href="#">Asia</a></li>
                  <li><a href="#">Americas</a></li>
                  <li><a href="#">Europe</a></li>
                  <li><a href="#">Africa</a></li>
                  <li><a href="#">Middle East</a></li>
                  <li><a href="#">Around the web</a></li>
                </ul>
              </div>
            </div>
          </div>

          <div class="col-md-2 col-sm-4">
            <div class="widget footer-widget">
              <header class="widget-header">
                <h4 class="title">
                  SPORT
                </h4>
              </header>
              <div class="widget-content">
                <ul class="list list-view">
                  <li><a href="#">Winter Games</a></li>
                  <li><a href="#">Tennis</a></li>
                  <li><a href="#">Golf</a></li>
                  <li><a href="#">Skiing</a></li>
                  <li><a href="#">Motorsport</a></li>
                  <li><a href="#">Football</a></li>
                  <li><a href="#">Hores racing</a></li>
                  <li><a href="#">Sailing</a></li>
                  <li><a href="#">Bleacher Report</a></li>
                </ul>
              </div>
            </div>
          </div>

          <div class="col-md-2 col-sm-4">
            <div class="widget footer-widget">
              <header class="widget-header">
                <h4 class="title">
                  entertainment
                </h4>
              </header>
              <div class="widget-content">
                <ul class="list list-view">
                  <li><a href="#">Quote board</a></li>
                  <li><a href="#">Best of 2013</a></li>
                  <li><a href="#">Showbiz tonight</a></li>
                  <li><a href="#">Fall entertainment 2013</a></li>
                  <li><a href="#">Photo gallery</a></li>
                  <li><a href="#">Music</a></li>
                  <li><a href="#">Let's talk tv</a></li>
                </ul>
              </div>
            </div>
          </div>

          <div class="col-md-2 col-sm-4">
            <div class="widget footer-widget">
              <header class="widget-header">
                <h4 class="title">
                  Technology
                </h4>
              </header>
              <div class="widget-content">
                <ul class="list list-view">
                  <li><a href="#">Socail media</a></li>
                  <li><a href="#">Mobile</a></li>
                  <li><a href="#">Web</a></li>
                  <li><a href="#">Gaming & Gadgets</a></li>
                  <li><a href="#">Innovation</a></li>
                  <li><a href="#">Tech biz</a></li>
                </ul>
              </div>
            </div>
          </div>


        </div>
      </div>
    </div><!--/site-bottom-->

    <footer class="site-footer">
      <div class="container footer-view">
        <div class="row">

          <div class="col-md-6 col-sm-6 copyright">
            <span>Copyright 2014 © NCC Magazine. </span>
          </div>

          <div class="col-md-6 col-sm-6 footer-link">
            <ul class="menu">
              <li><a href="#">TERMS OF US</a></li>
              <li><a href="#">PRIVACY POLICY</a></li>
            </ul>
          </div>

        </div><!--/footer-view .row-->
      </div><!--/footer-view-->
    </footer><!--/site-footer-->

        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>

        <script>window.jQuery || document.write('<script src="js/vendor/jquery-1.10.1.min.js"><\/script>')</script>

        <script src="js/vendor/bootstrap.min.js"></script>

        <!-- plugin js-->
        <script src="js/jquery.bxslider.min.js"></script>

        <script src="js/main.js"></script>

    </body>
</html>
