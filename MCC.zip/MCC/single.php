

<?php

//echo $_SERVER['REQUEST_URI'];
//echo  $_SERVER['SERVER_NAME'] ;
include("connection.php");
global $conn;

ini_set('display_errors',1);
ini_set('log_errors',1);
    // print_r($_REQUEST)       ;
if(isset($_REQUEST['newsid']) )
{
   $sqllatest = "SELECT * FROM world_rss as wrs left join category as catg  on wrs.category_id=catg.id where wrs.id = '".$_REQUEST['newsid']."' ";
   $resultlatest = $conn->query($sqllatest);

if ($resultlatest->num_rows > 0) {

           $incre_num = 1;

            		foreach($resultlatest as $rowlatest) {

             $image = 'http://tesco.press/images/'.$rowlatest['category'].'/'.$rowlatest['media'] ;
             $title = $rowlatest['title'];
             $description = $rowlatest['description'];
             $newsurl = $rowlatest['guid'];
             $category = $rowlatest['category_id'];


            }

            }
 }


?>

<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width">

        <!-- plugin-->

        <!-- basic-->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/main.css">
        <link rel="stylesheet" href="css/widget.css">
        <link rel="stylesheet" href="css/layout.css">

        <!-- modules-->
        <link rel="stylesheet" href="css/modules/form.css">
        <link rel="stylesheet" href="css/modules/media.css">

        <!-- layouts-->
        <link rel="stylesheet" href="css/layouts/news.css">

        <script src="js/vendor/modernizr-2.6.2-respond-1.1.0.min.js"></script>
    </head>
    <body class="single-page">

  <?php include("menu.php");  ?>
    <div class="container full-page">
      <div class="row">

        <!-- <div class="banner-view widget">
          <img src="img/ad.jpg" alt="">
        </div> -->

        <div class="breadcrumb-wrapper">
          <ol class="breadcrumb">
            <li><a href="#">Home</a></li>
            <li><a href="#">Blog</a></li>
            <li class="active">Single Post</li>
          </ol>
        </div><!--/breadcrumb-wrapper-->


        <div class="post-container container">

          <div class="col-md-9 news-post-format post-view content">
            <div class="post clearfix">

                <header class="page-header">
                  <div class="page-title">
                    <h2 class="title">Up On The Wall: How Working Walls Unlock Creative Insight</h2>
                    <div class="meta-wrapper">
                      <span class="meta"><i class="fa fa-pencil-square-o"></i> Alanna K. Stuckey</span>
                      <span class="meta"><i class="fa fa-calendar"></i> Sep 23, 2013</span>
                      <span class="meta"><i class="fa fa-comment-o"></i> 10</span>
                    </div>
                  </div>
                </header>

                <img src="img/post_1.jpg" alt="" class="post-thumbnail">
                <p>
                  <em>
                    <strong>Editor's note:</strong> To mark the 25th anniversary of the fall of the Berlin Wall, CNN is again airing its epic 24-part documentary series on the <a href="http://edition.cnn.com/SPECIALS/coldwar">Cold War</a>.
                  </em>
                </p>
                <div class="news-segment small">
                  <strong>STORY HIGHLIGHTS</strong>
                  <ul class="list">
                    <li>CNN International is again airing its 24-part series, The Cold War, which first aired in 1998</li>
                    <li>The Cold War shows how the events of yesterday have shaped the world of today</li>
                    <li>Series was narrated by Academy Award nominated actor Sir Kenneth Branagh</li>
                  </ul>
                </div>
                <p>The struggle between communism and capitalism defined the second half of the 20th Century. The Cold War pitted east against west, pushing the world to the brink of nuclear war.</p>
                <p>Now, as we approach the 25th anniversary of the fall of the Berlin Wall, which brought the era to a close, CNN International is again airing its 24-part series, The Cold War, which first aired in 1998. Giving unparalleled insight from those who lived and fought through the events that defined an era, The Cold War lets viewers see how the events of yesterday have shaped the world of today.</p>
                <p>The series was commissioned by CNN founder Ted Turner. Award-winning television director Jeremy Isaacs was the executive producer. The series was narrated by Academy Award nominated actor Sir Kenneth Branagh.
                The programs will air on CNN International every two weeks starting on January 4. Here is a summary of the first 12 episodes.</p>
                <p><strong>Consumers: More fees, tighter seats, "connected" flight attendants</strong></p>
                <p>The Russian Revolution of 1917, followed by the Russian Civil War caused a rift between the Soviet Union and the United States. But when President Franklin Roosevelt took office in 1933, diplomatic and trade relations between the two countries resumed. The relationship was strained yet again after the USSR annexed the Baltic States and signed a non-aggression pact with Nazi Germany.</p>
                <p>Despite their differences the Soviet Union and the United States found themselves allied after the German invasion of Russia in June 1941. As the war in Europe began to wind down and victory was in sight, the two countries had very different views as to what the post-war world would look like. At the Potsdam Conference, just before the atom bomb was dropped on Japan, it became clear that Stalin wanted to put Eastern Europe under the Soviet sphere of influence, setting the conditions for the Cold War to commence. Episode 1 includes interviews from George F. Kennan, Zoya Zarubina, Hugh Lunghi and George Elsey.</p>
                <p><a href="#">MORE: How to battle the shrinking airline seat</a></p>
                <div class="news-segment small">
                  <figure>
                    <img src="img/post_2.jpg" alt="">
                    <figcaption>
                      Following the merger with US Airways in December, American Airlines is now the world's biggest airline.
                    </figcaption>
                  </figure>
                </div>
                <p>As wartime turned to peacetime, a resurgent United States enjoys economic prosperity while Europe is left to recover from the ravages of war. In the Soviet Union, Stalin has resumed his feared purges and the country is gripped by famine. Germany is forced to cede some of its eastern territory to Poland, and the Germans living in that area are expelled from their homes. Stalin begins to increase his hold on Eastern Europe, installing communist regimes, but decides to stay out of the Greek Civil War.</p>
                <p>The United Kingdom, exhausted from the war, sees its once-powerful empire go into decline. As food shortages begin to threaten the stability of Europe, a more assertive United States begins to challenge the USSR's influence in both Turkey and Iran. Episode 2 includes interviews from Lord Annan, Sir Frank Roberts and Paul Nitze.</p>
                <p><strong>Airbus: End of the line for A350-800?</strong></p>
                <p>Traditionally operating in the shadows cast by Boeing and Airbus, the Canadian aircraft company will have to sweat a bit if it wants to steal some of the spotlight it bid for in 2013.</p>
                <div class="news-segment">
                  <blockquote>
                    <p>I think we're going to unleash the power of Bitcoin</p>
                    <small>Jordan Kelley, Robocoin CEO <cite title="Source Title">Source Title</cite></small>
                  </blockquote>
                </div>
                <p>This makes it one of the more interesting players to watch in the year ahead</p>
                <p>Bombardier's CSeries aircraft made its first flight September 16. Since then, company officials have stuck with an aggressive entry-into-service (EIS) plan to follow within 12 months</p>
                <p>Slower than expected progress on flight-testing and a test schedule largely discounted as too optimistic, however, have led most aerospace analysts to conclude that the aircraft won't likely see service until the first quarter of 2015.</p>
                <p>China's central bank issued new rules in December that prohibited financial institutions from dealing in the digital currency. While it did not outlaw individuals from owning Bitcoin, it specifies that it is not to be considered a currency.</p>
                <p>Despite the setback, Robocoin's chief executive said he still firmly believes China will come to accept Bitcoin.</p>
                <p>"Citizens around the world love Bitcoin. The Chinese are very pragmatic in their approach, they just want to make sure they have a very good understanding of the market and the usage," he said.Kelley revealed that Robocoin has begun talks with several operators in China that are reaching out to the government and local regulators to "educate" them about the value and potential of the Bitcoin market.</p>
            </div><!--/post-->

            <footer class="post-footer clearfix">

              <div class="comment-count pull-left">
                <a href="#comment-view"><b>16 Comments</b></a>
              </div>

              <ul class="pagination pull-right">
                <li>Pages:</li>
                <li class="active"><a href="#">1</a></li>
                <li><a href="#">2</a></li>
                <li><a href="#">3</a></li>
                <li><a href="#">4</a></li>
              </ul>

            </footer>

            <div class="related-post margin-top-20 clearfix">
               <header class="widget-header">
                  <h4 class="title">
                    We recommend
                  </h4>
                </header>

              <div class="post col-md-3 col-sm-3 col-xs-12">
                <img src="img/post_1.jpg" alt="" class="post-thumbnail">
                <div class="title">
                  <a>Gay waitress loses job after investigation into whether customers denied tip.
                  </a>
                </div>
              </div><!--/post-->

              <div class="post col-md-3 col-sm-3 col-xs-12">
                <img src="img/post_2.jpg" alt="" class="post-thumbnail">
                <div class="title">
                  <a>Can wind towers take the heat off UAE's air-con addiction?
                  </a>
                </div>
              </div><!--/post-->

              <div class="post col-md-3 col-sm-3 col-xs-12">
                <img src="img/post_3.jpg" alt="" class="post-thumbnail">
                <div class="title">
                  <a>Shia LaBeouf offers cloudy plagiarism apology
                  </a>
                </div>
              </div><!--/post-->

              <div class="post col-md-3 col-sm-3 col-xs-12">
                <img src="img/post_4.jpg" alt="" class="post-thumbnail">
                <div class="title">
                  <a>Advances in Metastatic Melanoma
                  </a>
                </div>
              </div><!--/post-->

              </div><!--/related-post-->

              <div id="comment-view" class="comment clearfix">
                <header class="widget-header">
                  <h4 class="title">
                    16 COMMENTS
                  </h4>
                </header>
                <ul class="list">
                  <li class="media">
                    <a href="" class="pull-left">
                      <img src="img/avatar32.jpg" alt="" class="avatar media-object">
                    </a>
                    <div class="media-body">
                      <h6 href="#" class="media-heading">FuqueIslamb <span data-role="relative-time" class="meta time-ago">26 minutes ago</span></h6>
                      <p>One of today's leading <a href="#">theoreticians</a> of the Islamist movement, Yussuf al-Ayyeri, published a book (available on the Internet) in which he warned that the real threat to Islam didn't come from American tanks and helicopter gunships in Iraq, but from the idea that democracy is the rule of the people.</p>
                      <footer class="comment-item-footer">
                        <ul class="list-inline">
                          <li><a href="#">Reply</a></li>
                          <li><a href="#">share</a></li>
                          <li><a href="#">edit</a></li>
                        </ul>
                      </footer>
                    </div>
                    <ul class="children">
                      <li class="media">
                        <a href="" class="pull-left">
                          <img src="img/avatar32.jpg" alt="" class="avatar media-object">
                        </a>
                        <div class="media-body">
                          <h6 href="#" class="media-heading">FuqueIslamb <span data-role="relative-time" class="meta time-ago">15 hours ago</span></h6>
                          <p>One of today's leading theoreticians of the Islamist movement, Yussuf al-Ayyeri, published a book (available on the Internet) in which he warned that the real threat to Islam didn't come from American tanks and helicopter gunships in Iraq, but from the idea that democracy is the rule of the people.</p>
                          <footer class="comment-item-footer">
                            <ul class="list-inline">
                              <li><a href="#">Reply</a></li>
                              <li><a href="#">share</a></li>
                              <li><a href="#">edit</a></li>
                            </ul>
                          </footer>
                        </div>
                        <ul class="children">
                          <li class="media">
                            <a href="" class="pull-left">
                              <img src="img/avatar32.jpg" alt="" class="avatar media-object">
                            </a>
                            <div class="media-body">
                              <h6 href="#" class="media-heading">FuqueIslamb <span data-role="relative-time" class="meta time-ago">19 hours ago</span></h6>
                              <p>One of today's leading theoreticians of the Islamist movement, Yussuf al-Ayyeri, published a book (available on the Internet) in which he warned that the real threat to Islam didn't come from American tanks and helicopter gunships in Iraq, but from the idea that democracy is the rule of the people.</p>
                              <footer class="comment-item-footer">
                                <ul class="list-inline">
                                  <li><a href="#">Reply</a></li>
                                  <li><a href="#">share</a></li>
                                  <li><a href="#">edit</a></li>
                                </ul>
                              </footer>
                          </li>
                        </ul>
                      </li>
                    </ul>
                  </li>

                  <li class="media">
                    <a href="" class="pull-left">
                      <img src="img/avatar32.jpg" alt="" class="avatar media-object">
                    </a>
                    <div class="media-body">
                      <h6 href="#" class="media-heading">FuqueIslamb <span data-role="relative-time" class="meta time-ago">26 minutes ago</span></h6>
                      <p>One of today's leading <a href="#">theoreticians</a> of the Islamist movement, Yussuf al-Ayyeri, published a book (available on the Internet) in which he warned that the real threat to Islam didn't come from American tanks and helicopter gunships in Iraq, but from the idea that democracy is the rule of the people.</p>
                      <footer class="comment-item-footer">
                        <ul class="list-inline">
                          <li><a href="#">Reply</a></li>
                          <li><a href="#">share</a></li>
                          <li><a href="#">edit</a></li>
                        </ul>
                      </footer>
                    </div>
                  </li>

                  <li class="media">
                    <a href="" class="pull-left">
                      <img src="img/avatar32.jpg" alt="" class="avatar media-object">
                    </a>
                    <div class="media-body">
                      <h6 href="#" class="media-heading">FuqueIslamb <span data-role="relative-time" class="meta time-ago">26 minutes ago</span></h6>
                      <p>One of today's leading <a href="#">theoreticians</a> of the Islamist movement, Yussuf al-Ayyeri, published a book (available on the Internet) in which he warned that the real threat to Islam didn't come from American tanks and helicopter gunships in Iraq, but from the idea that democracy is the rule of the people.</p>
                      <footer class="comment-item-footer">
                        <ul class="list-inline">
                          <li><a href="#">Reply</a></li>
                          <li><a href="#">share</a></li>
                          <li><a href="#">edit</a></li>
                        </ul>
                      </footer>
                    </div>
                    <ul class="children">
                      <li class="media">
                        <a href="" class="pull-left">
                          <img src="img/avatar32.jpg" alt="" class="avatar media-object">
                        </a>
                        <div class="media-body">
                          <h6 href="#" class="media-heading">FuqueIslamb <span data-role="relative-time" class="meta time-ago">19 hours ago</span></h6>
                          <p>One of today's leading theoreticians of the Islamist movement, Yussuf al-Ayyeri, published a book (available on the Internet) in which he warned that the real threat to Islam didn't come from American tanks and helicopter gunships in Iraq, but from the idea that democracy is the rule of the people.</p>
                          <footer class="comment-item-footer">
                            <ul class="list-inline">
                              <li><a href="#">Reply</a></li>
                              <li><a href="#">share</a></li>
                              <li><a href="#">edit</a></li>
                            </ul>
                          </footer>
                      </li>
                    </ul>
                  </li>
                </ul>

                <div class="load-more cleafix" data-role="more">
                  <a href="#" data-action="more-posts" class="btn col-md-12">Load more comments</a>
                </div>

              </div><!--/comment-->

              <div id="reply-view" class="reply clearfix margin-top-20">
                <header class="widget-header">
                  <h4 class="title">
                    LEAVE A REPLY
                  </h4>
                </header>

                <form action="" role="form" class="margin-top-20">
                  <div class="col-md-4">
                    <div class="form-group">
                      <label for="name" class="sr-only">Name(required):</label>
                      <input type="name" class="form-control" id="name" placeholder="Name *">
                    </div>
                    <div class="form-group">
                      <label for="email" class="sr-only">Email address(required):</label>
                      <input type="email" class="form-control" id="email" placeholder="Enter email *">
                    </div>
                    <div class="form-group">
                      <label for="website" class="sr-only">Website:</label>
                      <input type="password" class="form-control" id="website" placeholder="Password">
                    </div>
                  </div>
                  <div class="col-md-8">
                    <div class="form-group">
                        <label for="comment_message" class="required sr-only">Your comment <span>(required):</span></label>
                        <textarea name="message" id="comment-message" cols="88" rows="7" class="form-control" placeholder="Your comment *" required></textarea>
                    </div>
                  </div>
                  <div class="col-md-12">
                    <input type="submit" value="Post Comment" id="submit-comment" class="btn pull-right">
                  </div>

                </form>

              </div>

          </div><!--/news-post-format-->

          <aside class="col-md-3 sidebar">

            <div class="widget">
              <header class="widget-header">
                <h4 class="title">
                  Share with
                </h4>
              </header>
              <div class="widget-content">
                <div class="share-view margin-top-20">
                  <a href="#"><i class="fa fa-facebook-square"></i></a>
                  <a href="#"><i class="fa fa-twitter-square"></i></a>
                  <a href="#"><i class="fa fa-google-plus-square"></i></a>
                  <a href="#"><i class="fa fa-envelope"></i></a>
                  <a href="#"><i class="fa fa-print"></i></a>
                </div>
              </div>
            </div>

            <div class="widget">
              <header class="widget-header">
                <h4 class="title">
                  Tagged with
                </h4>
              </header>
              <div class="widget-content meta-tag">
                <div class="margin-top-20">
                  <a class="tag" href="#">Cold War</a>
                  <a class="tag" href="#">Russian Revolution</a>
                  <a class="tag" href="#">Czechoslovakia</a>
                </div>
              </div>
            </div>

            <div class="widget">
              <header class="widget-header">
                <h4 class="title">
                  Opinion
                </h4>
              </header>
              <div class="widget-content">
                <ul class="media-list list">
                  <li class="media">
                    <a href="#" class="pull-right">
                      <img src="img/avatar_1.jpg" alt="" class="media-object">
                    </a>
                    <div class="media-body">
                      <h4 class="media-heading title">
                        SUSAN MILLIGAN
                      </h4>
                      <p>UPS Delivers Christmas a Day Late</p>
                    </div>
                  </li>
                  <li class="media">
                    <a href="#" class="pull-right">
                      <img src="img/avatar_2.jpg" alt="" class="media-object">
                    </a>
                    <div class="media-body">
                      <h4 class="media-heading title">
                        CHARLES WHEELAN
                      </h4>
                      <p>Political Resolutions for 2014</p>
                    </div>
                  </li>
                  <li class="media">
                    <a href="#" class="pull-right">
                      <img src="img/avatar_3.jpg" alt="" class="media-object">
                    </a>
                    <div class="media-body">
                      <h4 class="media-heading title">
                        MORT ZUCKERMAN
                      </h4>
                      <p>Looking Back at 2013</p>
                    </div>
                  </li>
                  <li class="media">
                    <a href="#" class="pull-right">
                      <img src="img/avatar_4.jpg" alt="" class="media-object">
                    </a>
                    <div class="media-body">
                      <h4 class="media-heading title">
                        PETER ROFF
                      </h4>
                      <p>America Just Isn't That Into Obama Anymore</p>
                    </div>
                  </li>
                </ul>
              </div>
            </div><!--/widget list-->

            <div class="widget form-view vote">
              <header class="widget-header">
                <h4 class="title">
                  QUICK VOTE
                </h4>
              </header>
              <div class="widget-content">
                <p class="margin-top-20">
                  Have you ever experienced rowdiness among other passengers on an airliner?
                </p>
                <form action="" class="form">
                  <div class="radio form-group radio-inline-group">
                    <label class="radio-inline iconlabel-wrapper ">
                      <input type="radio" name="optionsRadios" id="optionsRadios1" value="option1" checked>
                      <span class="radio-iconlabel"></span>Yes
                    </label>
                    <label class="radio-inline iconlabel-wrapper ">
                      <input type="radio" name="optionsRadios" id="optionsRadios1" value="option1" checked>
                      <span class="radio-iconlabel"></span>No
                    </label>
                  </div>
                  <hr class="clearfix">
                   <button type="submit" class="btn">vote</button> or <button type="submit" class="btn btn-link">view results</button>
                </form>
              </div>
            </div><!--/vote-->

            <div class="widget">
              <header class="widget-header">
                <h4 class="title">
                  In the News
                </h4>
              </header>
              <div class="widget-content">
                <ul class="list list-view">
                  <li class="title"><a href="#">Concussions Linked to Alzheimer's Risk in Study</a></li>
                  <li class="title"><a href="#">UNOS to oversee hand, face transplants like organs</a></li>
                  <li class="title"><a href="#">Family disputes claims in Norman Rockwell book</a></li>
                  <li class="title"><a href="#">'Booty Call,' 'Above the Rim' director dies at 54</a></li>
                  <li class="title"><a href="#">Aggies beat Lynch, No. 24 NIU 21-14 in Poinsettia</a></li>
                </ul>
              </div>
            </div><!--/widget list-->

            <div class="widget banner">
              <header class="widget-header">
                <h4 class="title">
                  Advertisement
                </h4>
              </header>
              <img src="img/banner_250.jpg" alt="">
            </div><!--/widget banner-->

            <div class="widget">
              <header class="widget-header">
                <h4 class="title">
                  MOST POPULAR
                </h4>
              </header>
              <div class="margin-top-20">
                <ul class="media-list list">
                  <li class="media">
                    <div class="title margin-bottom-10">
                      <a href="#">Scenes from the field</a>
                    </div>
                    <a href="#" class="pull-left">
                      <img src="img/aside_post_1.jpg" alt="" class="media-object">
                    </a>
                    <div class="media-body">
                      <p class="small">Browse through images you don't always see in news reports, taken by CNN teams all around the world.</p>
                    </div>
                  </li>
                  <li class="media">
                    <div class="title margin-bottom-10">
                      <a href="#">Heroes or villains? Cricket's rebels</a>
                    </div>
                    <a href="#" class="pull-left">
                      <img src="img/aside_post_2.jpg" alt="" class="media-object">
                    </a>
                    <div class="media-body">
                      <p class="small">Gareth Evans was just a small boy when a team of West Indies cricketers arrived in apartheid South Africa. Their lives would never be the same.</p>
                    </div>
                  </li>
                  <li class="media">
                    <div class="title margin-bottom-10">
                      <a href="#">Heroes or villains? Cricket's rebels</a>
                    </div>
                    <a href="#" class="pull-left">
                      <img src="img/aside_post_3.jpg" alt="" class="media-object">
                    </a>
                    <div class="media-body">
                      <p class="small">Gareth Evans was just a small boy when a team of West Indies cricketers arrived in apartheid South Africa. Their lives would never be the same.</p>
                    </div>
                  </li>
                  <li class="media">
                    <div class="title margin-bottom-10">
                      <a href="#">New year, chance to reclaim humanity?</a>
                    </div>
                    <a href="#" class="pull-left">
                      <img src="img/aside_post_4.jpg" alt="" class="media-object">
                    </a>
                    <div class="media-body">
                      <p class="small">Gareth Evans was just a small boy when a team of West Indies cricketers arrived in apartheid South Africa. Their lives would never be the same.</p>
                    </div>
                  </li>
                  <li class="media">
                    <div class="title margin-bottom-10">
                      <a href="#">Tribesmen join forces vs. al Qaeda</a>
                    </div>
                    <a href="#" class="pull-left">
                      <img src="img/aside_post_5.jpg" alt="" class="media-object">
                    </a>
                    <div class="media-body">
                      <p class="small">Gareth Evans was just a small boy when a team of West Indies cricketers arrived in apartheid South Africa. Their lives would never be the same.</p>
                    </div>
                  </li>
                  <li class="media">
                    <div class="title margin-bottom-10">
                      <a href="#">Six odd and crazy technologies</a>
                    </div>
                    <a href="#" class="pull-left">
                      <img src="img/aside_post_6.jpg" alt="" class="media-object">
                    </a>
                    <div class="media-body">
                      <p class="small">Gareth Evans was just a small boy when a team of West Indies cricketers arrived in apartheid South Africa. Their lives would never be the same.</p>
                    </div>
                  </li>
                </ul>
              </div>
            </div><!--/widget list-->

            <div class="widget">
              <header class="widget-header">
                <h4 class="title">
                  TRENDING NOW
                </h4>
              </header>
              <ul class="media list">
                <li class="media">
                  <div href="#" class="widget-thumbnail hover-thumbnail video-box">
                    <a href="#" class="media-object"><img src="img/11.jpg" alt=""></a>
                  </div>
                  <div class="media-body margin-top-10">
                    <h4 class="media-heading title">
                      <a href="#">Not your average steering wheel</a>
                    </h4>
                    <p>Explore our interactive of one of F1's most important and complicated pieces of kit.</p>
                  </div>
                </li>
              </ul>
            </div>

          </aside>

        </div><!--/post-view-->

      </div><!--/full-page-->
    </div><!-- /main-view -->

    <div class="site-bottom hidden-xs">
      <div class="container">
        <div class="row">

          <div class="col-md-2 col-sm-4">
            <div class="widget footer-widget">
              <header class="widget-header">
                <h4 class="title">
                  ABOUT NCC theme
                </h4>
              </header>
              <div class="widget-content">
                <ul class="list list-view">
                  <li><a href="#">Theme style</a></li>
                  <li><a href="#">Page information</a></li>
                  <li><a href="#">RWD design</a></li>
                  <li><a href="#">Clean and easy to use</a></li>
                </ul>
              </div>
              <header class="widget-header">
                <h4 class="title">
                  SITE SERVICe
                </h4>
              </header>
              <div class="widget-content">
                <ul class="list list-view">
                  <li><a href="#">Promo Events</a></li>
                  <li><a href="#">Sweepstakes</a></li>
                  <li><a href="#">Newsletter</a></li>
                </ul>
              </div>
            </div>
          </div>

          <div class="col-md-2 col-sm-4">
            <div class="widget footer-widget">
              <header class="widget-header">
                <h4 class="title">
                  BUSINESS
                </h4>
              </header>
              <div class="widget-content">
                <ul class="list list-view">
                  <li><a href="#">The gateway</a></li>
                  <li><a href="#">Business Traveller</a></li>
                  <li><a href="#">Leading Women</a></li>
                  <li><a href="#">Companies News</a></li>
                  <li><a href="#">Markets News</a></li>
                  <li><a href="#">NCC Money</a></li>
                  <li><a href="#">NCC TW</a></li>
                </ul>
              </div>
            </div>
          </div>

          <div class="col-md-2 col-sm-4">
            <div class="widget footer-widget">
              <header class="widget-header">
                <h4 class="title">
                  WORLD
                </h4>
              </header>
              <div class="widget-content">
                <ul class="list list-view">
                  <li><a href="#">On the Road</a></li>
                  <li><a href="#">Celebrates</a></li>
                  <li><a href="#">Security Clearance</a></li>
                  <li><a href="#">Girl Rising</a></li>
                  <li><a href="#">NCC affiliates</a></li>
                  <li><a href="#">Asia</a></li>
                  <li><a href="#">Americas</a></li>
                  <li><a href="#">Europe</a></li>
                  <li><a href="#">Africa</a></li>
                  <li><a href="#">Middle East</a></li>
                  <li><a href="#">Around the web</a></li>
                </ul>
              </div>
            </div>
          </div>

          <div class="col-md-2 col-sm-4">
            <div class="widget footer-widget">
              <header class="widget-header">
                <h4 class="title">
                  SPORT
                </h4>
              </header>
              <div class="widget-content">
                <ul class="list list-view">
                  <li><a href="#">Winter Games</a></li>
                  <li><a href="#">Tennis</a></li>
                  <li><a href="#">Golf</a></li>
                  <li><a href="#">Skiing</a></li>
                  <li><a href="#">Motorsport</a></li>
                  <li><a href="#">Football</a></li>
                  <li><a href="#">Hores racing</a></li>
                  <li><a href="#">Sailing</a></li>
                  <li><a href="#">Bleacher Report</a></li>
                </ul>
              </div>
            </div>
          </div>

          <div class="col-md-2 col-sm-4">
            <div class="widget footer-widget">
              <header class="widget-header">
                <h4 class="title">
                  entertainment
                </h4>
              </header>
              <div class="widget-content">
                <ul class="list list-view">
                  <li><a href="#">Quote board</a></li>
                  <li><a href="#">Best of 2013</a></li>
                  <li><a href="#">Showbiz tonight</a></li>
                  <li><a href="#">Fall entertainment 2013</a></li>
                  <li><a href="#">Photo gallery</a></li>
                  <li><a href="#">Music</a></li>
                  <li><a href="#">Let's talk tv</a></li>
                </ul>
              </div>
            </div>
          </div>

          <div class="col-md-2 col-sm-4">
            <div class="widget footer-widget">
              <header class="widget-header">
                <h4 class="title">
                  Technology
                </h4>
              </header>
              <div class="widget-content">
                <ul class="list list-view">
                  <li><a href="#">Socail media</a></li>
                  <li><a href="#">Mobile</a></li>
                  <li><a href="#">Web</a></li>
                  <li><a href="#">Gaming & Gadgets</a></li>
                  <li><a href="#">Innovation</a></li>
                  <li><a href="#">Tech biz</a></li>
                </ul>
              </div>
            </div>
          </div>


        </div>
      </div>
    </div><!--/site-bottom-->

    <footer class="site-footer">
      <div class="container footer-view">
        <div class="row">

          <div class="col-md-6 col-sm-6 copyright">
            <span>Copyright 2014 © NCC Magazine. </span>
          </div>

          <div class="col-md-6 col-sm-6 footer-link">
            <ul class="menu">
              <li><a href="#">TERMS OF US</a></li>
              <li><a href="#">PRIVACY POLICY</a></li>
            </ul>
          </div>

        </div><!--/footer-view .row-->
      </div><!--/footer-view-->
    </footer><!--/site-footer-->

        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>

        <script>window.jQuery || document.write('<script src="js/vendor/jquery-1.10.1.min.js"><\/script>')</script>

        <script src="js/vendor/bootstrap.min.js"></script>

        <!-- plugin js-->
        <script src="js/jquery.bxslider.min.js"></script>

        <script src="js/main.js"></script>

    </body>
</html>
