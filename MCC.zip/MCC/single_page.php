<?php


include("connection.php");
global $conn;

ini_set('display_errors',1);
ini_set('log_errors',1);


    // print_r($_REQUEST)       ;


if(isset($_REQUEST['newsid']) )
{
   $sqllatest = "SELECT * FROM world_rss as wrs left join category as catg  on wrs.category_id=catg.id where wrs.id = '".$_REQUEST['newsid']."' ";
   $resultlatest = $conn->query($sqllatest);	
          
if ($resultlatest->num_rows > 0) {	
            
           $incre_num = 1;

            		foreach($resultlatest as $rowlatest) {  

             $image = 'http://tesco.press/images/'.$rowlatest['category'].'/'.$rowlatest['media'] ;
             $title = $rowlatest['title']; 
             $description = $rowlatest['description'];
             $newsurl = $rowlatest['guid'];
             $category = $rowlatest['category_id'];            
            
 
            } 				
            
            }  
 }


?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Tesco.press /<?php echo $title; ?> </title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- for fontawesome icon css file -->
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <!-- for content animate css file -->
    <link rel="stylesheet" href="css/animate.css">
    <!-- google fonts  -->
    <link href='http://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Varela' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>   
    <!-- for news ticker css file -->
     <link href="css/li-scroller.css" rel="stylesheet">
     <!-- slick slider css file -->
    <link href="css/slick.css" rel="stylesheet">
    <!-- for fancybox slider -->
     <link href="css/jquery.fancybox.css" rel="stylesheet"> 
    <!-- website theme file -->
    <!-- <link href="css/theme-red.css" rel="stylesheet"> -->
 
     <link href="css/theme.css" rel="stylesheet">
    <!-- main site css file -->    
    <link href="style.css" rel="stylesheet">
 

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
<body>

  

  <!-- =========================
    //////////////This Theme Design and Developed //////////////////////
    //////////// by www.wpfreeware.com======================-->

  <!-- Preloader -->
  <div id="preloader">
    <div id="status">&nbsp;</div>
  </div>
  <!-- End Preloader -->
   
  <a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a>
  
  <div class="container">
    <!-- start header section -->
   <?php include("menu.php");   ?>
      
     <!-- =========================
      //////////////This Theme Design and Developed //////////////////////
      //////////// by www.wpfreeware.com======================-->

    <!-- ==================start content body section=============== -->
    <section id="contentSection">
      <div class="row">
        <div class="col-lg-8 col-md-8 col-sm-8">
          <div class="left_content">
            <div class="single_page">
              <ol class="breadcrumb">
                <li><a href="index.html">Home</a></li>
                <li><a href="#">Technology</a></li>
                <li class="active">Mobile</li>
              </ol>
              <h1><?php echo $title; ?></h1>
              <div class="post_commentbox">
                <a href="#"><i class="fa fa-user"></i>Wpfreeware</a>
                <span><i class="fa fa-calendar"></i>6:49 AM</span>
                <a href="#"><i class="fa fa-tags"></i>Technology</a>
              </div>
              <div class="single_page_content">
                <img class="img-center" src="<?php echo $image; ?>" alt="img">
                <p><?php echo $description; ?></p>
                <blockquote>
                    <a href="<?php echo $newsurl; ?>">more </a>
                </blockquote>
              
                    
              <!--  <button class="btn default-btn">Default</button>
                <button class="btn btn-red">Red Button</button>
                <button class="btn btn-yellow">Yellow Button</button>
                <button class="btn btn-green">Green Button</button>
                <button class="btn btn-black">Black Button</button>
                <button class="btn btn-orange">Orange Button</button>
                <button class="btn btn-blue">Blue Button</button>
                <button class="btn btn-lime">Lime Button</button>
                <button class="btn btn-theme">Theme Button</button> -->
              </div>
              <div class="social_link">
                <ul class="sociallink_nav">
                  <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                  <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                  <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                  <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                  <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
                </ul>
              </div>
              <div class="related_post">
                <h2>Related Post <i class="fa fa-thumbs-o-up"></i></h2>
                <ul class="spost_nav wow fadeInDown animated">
                    
    <?php     
                    
   $sqllatest = "SELECT * FROM world_rss as wrs left join category as catg  on wrs.category_id=catg.id where wrs.category_id = '".$category."' limit 0,3 ";
   $resultlatest = $conn->query($sqllatest);
  
   if ($resultlatest->num_rows > 0) {	            
    $incre_num = 1;
	foreach($resultlatest as $rowlatest) { 
        $image = 'http://tesco.press/images/'.$rowlatest['category'].'/'.$rowlatest['media'] ;            
        ?>
         
        <li>
                    <div class="media">
                      <a class="media-left" href="single_page.php?newsid=<?php echo $rowlatest['wid']; ?>">
                        <img class="img-center" src="<?php echo $image; ?>" alt="img">
                      </a>
                      <div class="media-body">
                        <a class="catg_title" href="single_page.php?newsid=<?php echo $rowlatest['wid']; ?>"> 
                          <?php echo $rowlatest['title']; ?></a>                        
                      </div>
                    </div>
                  </li>
    <?php     
    }
   }
         ?>           
                    
                    
                    
                  
                   <li>
                    <div class="media">
                      <a class="media-left" href="single_page.html">
                        <img src="img/post_img2.jpg" alt="img">
                      </a>
                      <div class="media-body">
                        <a class="catg_title" href="single_page.html"> Aliquam malesuada diam eget turpis varius</a>                                
                      </div>
                    </div>
                  </li>
                  <li>
                    <div class="media">
                      <a class="media-left" href="single_page.html">
                        <img src="img/post_img1.jpg" alt="img">
                      </a>
                      <div class="media-body">
                        <a class="catg_title" href="single_page.html"> Aliquam malesuada diam eget turpis varius</a>                               
                      </div>
                    </div>
                  </li>               
                </ul>
              </div>
            </div>            
          </div>
        </div>
        <nav class="nav-slit">
              <a class="prev" href="/item1">
                <span class="icon-wrap"><i class="fa fa-angle-left"></i></span>
                <div>
                  <h3>City Lights</h3>
                  <img src="img/post_img1.jpg" alt="Previous thumb"/>
                </div>
              </a>
              <a class="next" href="/item3">
                <span class="icon-wrap"><i class="fa fa-angle-right"></i></span>
                <div>
                  <h3>Street Hills</h3>
                  <img src="img/post_img1.jpg" alt="Next thumb"/>
                </div>
              </a>
            </nav>
        <div class="col-lg-4 col-md-4 col-sm-4">
          <aside class="right_content">
            <div class="single_sidebar">
              <h2><span>Popular Post</span></h2>
              <ul class="spost_nav">
                  
                    <?php  $sqllatest = "SELECT *,wrs.id as wid FROM world_rss as wrs left join category as catg  on wrs.category_id=catg.id  group by category_id  ORDER BY UNIX_TIMESTAMP(datetime) DESC limit 0,5";

                    $resultlatest = $conn->query($sqllatest);	
                    $resultlatest->num_rows; 

                    if ($resultlatest->num_rows > 0) {							
                    $incre_num = 1;

                    foreach($resultlatest as $rowlatest) {  ?>

                    <li>
                      <div class="media">
                        <a href="single_page.php?newsid=<?php echo $rowlatest['wid']; ?>" class="media-left">
                          <img src="/images/<?php echo $rowlatest['category'].'/'.$rowlatest['media'];    ?>">
                        </a>
                        <div class="media-body">
                          <a href="single_page.php?newsid=<?php echo $rowlatest['wid']; ?>" class="catg_title"> <?php echo $rowlatest['title'];    ?> </a>                        
                        </div>
                      </div>
                    </li>    

                    <?php  } }   ?>

              </ul>
            </div>
            <!-- start tab section -->
            <div class="single_sidebar">
               <!-- Nav tabs -->
              <ul class="nav nav-tabs" role="tablist">
                <li role="presentation" class="active"><a href="#category" aria-controls="home" role="tab" data-toggle="tab">Gloom or Doom</a></li>
                <li role="presentation"><a href="#video" aria-controls="profile" role="tab" data-toggle="tab">Video</a></li>
                <li role="presentation"><a href="#comments" aria-controls="messages" role="tab" data-toggle="tab">Comments</a></li>               
              </ul>
              <div class="tab-content">
                <div role="tabpanel" class="tab-pane active" id="category">
                 <iframe width="100%" height="250" src="https://www.youtube.com/embed/a4B2CGpB86E?autoplay=1" frameborder="0" allowfullscreen></iframe>
                </div>
                <div role="tabpanel" class="tab-pane" id="video">
                  <div class="vide_area">                   
                    <iframe width="100%" height="250" src="https://www.youtube.com/embed/eH7hBiY9xkg?autoplay=0" frameborder="0" allowfullscreen></iframe>
                  </div>
                </div>
                <div role="tabpanel" class="tab-pane" id="comments">
                  <ul class="spost_nav">
                <li>
                  <div class="media wow fadeInDown">
                    <a href="single_page.php" class="media-left">
                     <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- second -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-9563089652950762"
     data-ad-slot="4984804829"
     data-ad-format="auto"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
                    <div class="media-body">
                      <a href="single_page.html" class="catg_title"> Aliquam malesuada diam eget turpis varius 2</a>                        
                    </div>
                  </div>
                </li>
                <li>
                  <div class="media wow fadeInDown">
                    <a href="single_page.html" class="media-left">
                      <img alt="img" src="img/post_img1.jpg">
                    </a>
                    <div class="media-body">
                      <a href="single_page.html" class="catg_title"> Aliquam malesuada diam eget turpis varius 3</a>                        
                    </div>
                  </div>
                </li>
                <li>
                  <div class="media wow fadeInDown">
                    <a href="single_page.html" class="media-left">
                      <img alt="img" src="img/post_img2.jpg">
                    </a>
                    <div class="media-body">
                      <a href="single_page.html" class="catg_title"> Aliquam malesuada diam eget turpis varius 4</a>                       
                    </div>
                  </div>
                </li>
              </ul>
                </div>
              </div>            
            </div>
            <!-- End tab section -->
            <!-- sponsor add -->
            <div class="single_sidebar wow fadeInDown">
              <h2><span>Sponsor</span></h2>
 <script charset="utf-8" type="text/javascript">
amzn_assoc_ad_type = "responsive_search_widget";
amzn_assoc_tracking_id = "tescosorguk-21";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "GB";
amzn_assoc_placement = "";
amzn_assoc_search_type = "search_widget";
amzn_assoc_width = 300;
amzn_assoc_height = 250;
amzn_assoc_default_search_category = "";
amzn_assoc_default_search_key = "";
amzn_assoc_theme = "light";
amzn_assoc_bg_color = "FFFFFF";
</script>
<script src="//z-eu.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&Operation=GetScript&ID=OneJS&WS=1&MarketPlace=GB"></script>


            </div>
            <!-- End sponsor add -->
             <!-- Category Archive -->
            <div class="single_sidebar wow fadeInDown">
              <h2><span>Category Archive</span></h2>

              <select class="catgArchive">
                <option>Select Category</option>
                <option>Life styles</option>
                <option>Sports</option>
                <option>Technology</option>
                <option>Treads</option>
              </select>
            </div>
            <!-- End category Archive -->
              <!-- sponsor add -->
            <div class="single_sidebar wow fadeInDown">
              <h2><span>Links</span></h2>
              <ul>
                <li><a href="#">Blog</a></li>
                <li><a href="#">Rss Feed</a></li>
                <li><a href="#">Login</a></li>
                <li><a href="#">Life & Style</a></li>
              </ul>
            </div>
            <!-- End sponsor add -->
          </aside>
        </div>
      </div>  
    </section>
    <!-- ==================End content body section=============== -->    
    <footer id="footer">       
      <div class="footer_top">
        <div class="row">
          <div class="col-lg-4 col-md-4 col-sm-4">
            <div class="footer_widget wow fadeInLeftBig">
              <h2>Ads support</h2>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- middle -->
<ins class="adsbygoogle"
     style="display:inline-block;width:336px;height:280px"
     data-ad-client="ca-pub-9563089652950762"
     data-ad-slot="6790039223"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
                       
            </div>
          </div>
          <div class="col-lg-4 col-md-4 col-sm-4">
            <div class="footer_widget wow fadeInDown">
              <h2>Tag</h2>
              <ul class="tag_nav">
                <li><a href="#">Games</a></li>
                <li><a href="#">Sports</a></li>
                <li><a href="#">Fashion</a></li>
                <li><a href="#">Business</a></li>
                <li><a href="#">Life & Style</a></li>
                <li><a href="#">Technology</a></li>
                <li><a href="#">Photo</a></li>
                <li><a href="#">Slider</a></li>
              </ul>              
            </div>
          </div>
          <div class="col-lg-4 col-md-4 col-sm-4">
            <div class="footer_widget wow fadeInRightBig">
              <h2>Contact</h2>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
              <address>
                Perfect News,1238 S . 123 St.Suite 25 Town City 3333,USA Phone: 123-326-789 Fax: 123-546-567 
              </address>              
            </div>
          </div>
        </div>
      </div>       
      <div class="footer_bottom">
        <p class="copyright">
          All Rights Reserved <a href="home.html">NewsFeed</a>
        </p>
        <p class="developer">Developed By <a href="http://wpfreeware.com">WpFreeware</a></p>
      </div>    
    </footer>
  </div> <!-- /.container -->
  

  <!-- jQuery Library -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script> 
  <!-- For content animatin  -->
  <script src="js/wow.min.js"></script>
  <!-- bootstrap js file -->
  <script src="js/bootstrap.min.js"></script> 
  <!-- slick slider js file -->
  <script src="js/slick.min.js"></script> 
  <!-- news ticker jquery file -->
  <script src="js/jquery.li-scroller.1.0.js"></script>
  <!-- for news slider -->
  <script src="js/jquery.newsTicker.min.js"></script>
  <!-- for fancybox slider -->
  <script src="js/jquery.fancybox.pack.js"></script>
  <!-- custom js file include -->    
  <script src="js/custom.js"></script> 

  <!-- =========================
        //////////////This Theme Design and Developed //////////////////////
        //////////// by www.wpfreeware.com======================-->
    
      
  </body>
</html>
