<?php

echo 'Hello';
error_reporting(E_ALL); ini_set('display_errors', 1);

include("connection.php");
global $conn;


require_once ('codebird/src/codebird.php');
\Codebird\Codebird::setConsumerKey('fJ14iYez7hU0N8a0VBqdjpsN1','4xAlJ652Fkrcmz42Zqp0KXveLM87JXDCrd85lj9EOrl3scvDt8'); // static, see README

$cb = \Codebird\Codebird::getInstance();

$cb->setToken('753895350923124736-Xwb7klAY3JnV4Cd6KlhM6iDaXwj3qHy', 'x9go2Hc1EQUBiEQoecvvz6R2i48FfrtrtomtkxaXBPhiQ');



 $sqllatest = "select * from world_rss";

$resultlatest = $conn->query($sqllatest);
echo $resultlatest->num_rows;
if ($resultlatest->num_rows > 0) {
$incre_num = 1;

foreach($resultlatest as $rowlatest) {

echo $title1 = $rowlatest['title'];
$reply = $cb->statuses_update('status='.$title1);

}
}
?>
