

<?php

ini_set('display_errors', 1); 



function _is_curl_installed() {
    if  (in_array  ('curl', get_loaded_extensions())) {
        return true;
    }
    else {
        return false;
    }
}

// Ouput text to user based on test
if (_is_curl_installed()) {
  echo "cURL is <span style=\"color:blue\">installed</span> on this server";
} else {
  echo "cURL is NOT <span style=\"color:red\">installed</span> on this server";
}



include("connection.php");
echo 'hello';
require_once ('codebird/src/codebird.php');

\Codebird\Codebird::setConsumerKey('3SnRMfhwhIefEwhqPFkZpOEZT','rVf3rBunw7TK0yVnWRrYNoo9s1cQKmTiY3ghZjXgdH1eFGrCAF'); // static, see README

$cb = \Codebird\Codebird::getInstance();

$cb->setToken('762576996958343168-k4sc02q3aUyHfD8Fe5USNT83lJxZQhj','2s6dLqM4x9IbBYoXr37Ab4L0QK2AGWxDS8TV2qQ6usruR');



//\Codebird\Codebird::setConsumerKey('iAeozAh3Sqt13IdmCPX0O1DjI','cK8So9FZ5AlkQtQlyflWZ8pGN6qsSCBMc2jpRjECKexCd52Teo'); // static, see README

//$cb = \Codebird\Codebird::getInstance();

//$cb->setToken('753895350923124736-54j0LhxCa1pkx0pHSqooRZUiMew5ftq', 'fj7TkMzag9jYmtShWVf4wusrOt5V2lAB2dMSEzCRjlgAs');


$tweet_text = array(); 
$tweet_url = array(); 
$counting =0; 



// $sqlm="select * from twitter_url";
 $rowm = mysqli_query($conect,"select * from twitter_url");
//$rowm=mysql_query($sqlm);


while($datam=mysqli_fetch_array($rowm))
 {
 $tweet_url[] =$datam['tweet_url'];
 // $reply = $cb->statuses_update('status='.$name);
 $tweet_text[] =$datam['tweet_text']; 
 }

$total = count($tweet_url);
$sql = "SELECT *,wrs.id as wid  FROM world_rss as wrs left join category as catg  on wrs.category_id=catg.id " ;

$rowm1=mysqli_query($conect,$sql);

while($datam=mysqli_fetch_array($rowm1))
 {
 echo $name =$datam['title']; 
//exit;
 $i = $counting%$total ; 
 $string = '  '.$tweet_url[$i].'  '.$tweet_text[$i];   
 $counting++;
  if($total == $counting) { $counting = 0 ; }
 


echo $url = $datam['category'].'/'.$datam['media'] ; 
echo $file = "http://tesco.press/images/".$url;
//echo $file = $datam['img_link'];

if(UR_exists($file)) {
      
  	$reply = $cb->media_upload(array('media' => $file));
	//upload the file to your twitter account
	 $mediaID = $reply->media_id_string; //.$string.'.r' 
         $message = $datam['title'].$string;
         //  $message = 
	//build the data needed to send to twitter, including the tweet and the image id
          
         $params = array('status' => $message,'media_ids' => $mediaID);
	//post the tweet with codebird
	 $reply = $cb->statuses_update($params);
        
        //$reply = $cb->statuses_update('status'.$message);
       // $reply = $cb->statuses_update('media_ids'.$mediaID);
     
      sleep(10);
}else
{    

$message = $datam['title'].$string ;
// $reply = $cb->statuses_update('status='.$name.$string);
$reply = $cb->statuses_update('status'.$message);    
 //$reply = $cb->media_upload(['media' => $file]);
//$reply = $cb->media_upload(array('media' => 'http://hpf.press/images1/justluxe1/o%20Other.jpg'));
     
   sleep(10);

 }
$id = $datam['id'];
//$updatesql = "update world_rss set status = 1 where id = $id ";
//mysqli_query($conect,$updatesql);


}
 

function UR_exists($url){
   $headers=get_headers($url);
   return stripos($headers[0],"200 OK")?true:false;
}


?>
