
<?php

error_reporting(1);
ini_set('error_reporting', E_ALL);


require_once ('codebird/src/codebird.php');
\Codebird\Codebird::setConsumerKey('f3yffxo7rKBzeLum5nj6V27DC','OEF0rf7TuRUCDPZxB1SnccIVP1ya9l2tHKHBdIvD4zomVWl2cA'); // static, see README

$cb = \Codebird\Codebird::getInstance();
$cb->setToken('752122997310386176-y3DujdybjUFA4JHFSPJJRnEmYbXisz3', 'lt0EB0qimwtzZuMC3FIFjxGFw2vMlP9phTzYZjj7x8Xeq');

//$reply = $cb->statuses_update('status=Whohoo, I just Tweeoytoted!');

$rowm = mysqli_query($conect,"select * from twitter_url");


while($datam=mysqli_fetch_array($rowm))
 {
 $tweet_url[] =$datam['tweet_url'];
 // $reply = $cb->statuses_update('status='.$name);
 $tweet_text[] =$datam['tweet_text'];
 }

/*
 $total = count($tweet_url);
 $sql = "SELECT *,wrs.id as wid  FROM world_rss as wrs left join category as catg  on wrs.category_id=catg.id where wrs.status=0" ;

 $rowm1=mysqli_query($conect,$sql);

 while($datam=mysqli_fetch_array($rowm1))
  {

  }
*/

  $file       = 'http://whatsmyip.tech/images/audio/Untitled.mp4';
  $size_bytes = filesize($file);

$ch = curl_init($file);
  curl_setopt($ch, CURLOPT_NOBODY, true);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_HEADER, true);
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

  $data = curl_exec($ch);
  curl_close($ch);
  echo '<br>';
  if (preg_match('/Content-Length: (\d+)/', $data, $matches)) {

      // Contains file size in bytes
      $contentLength = (int)$matches[1];

  }

echo  $size_bytes = $contentLength ;

echo '<br>';

//echo ($size_bytes/1024)1024 .'MB';

$fp  = fopen($file, 'r');

// INIT the upload

$reply = $cb->media_upload([
  'command'     => 'INIT',
  'media_type'  => 'video/mp4',
  'total_bytes' => $size_bytes,
  'media_category'=> 'tweet_video'
]);


print_r($reply);
 $media_id = $reply->media_id_string;
 $media_id ;
//print_r($media_id);

//exit;
// APPEND data to the upload

$segment_id = 0;

while (! feof($fp)) {
  $chunk = fread($fp, 1048576); // 1MB per chunk for this sample


  $reply = $cb->media_upload([
    'command'       => 'APPEND',
    'media_id'      => $media_id,
    'segment_index' => $segment_id,
    'media'         => $chunk
  ]);
   $segment_id++;
  //echo 'Hello';

}

fclose($fp);

// FINALIZE the upload

$reply = $cb->media_upload([
  'command'       => 'FINALIZE',
  'media_id'      => $media_id
]);

echo '<pre>';

var_dump($reply);

if ($reply->httpstatus < 200 || $reply->httpstatus > 299) {
  die();
}

// if you have a field `processing_info` in the reply,
// use the STATUS command to check if the video has finished processing.
// Now use the media_id in a Tweet

$media_id = $reply->media_id_string;

$reply2 = $cb->statuses_update([
  'status'    => 'Video Uploads ee.',
  'media_ids' => $media_id
]);

var_dump($reply2);


?>
